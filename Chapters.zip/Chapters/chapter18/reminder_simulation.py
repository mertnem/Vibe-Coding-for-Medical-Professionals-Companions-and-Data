import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent

SCHEMAS = {'simulation_plan.csv': ['per_group', 'usual_probability', 'reminder_probability', 'repetitions', 'seed']}

def read_rows(name):
    with (ROOT / name).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream, strict=True)
        if reader.fieldnames != SCHEMAS[name]:
            raise ValueError("Wrong header in " + name)
        rows = list(reader)
    if any(None in row or None in row.values() for row in rows):
        raise ValueError("Malformed CSV row in " + name)
    return rows

from datetime import date as _date



def save_rows(name, fields, rows):
    with (ROOT / name).open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

import random,statistics

plans=read_rows("simulation_plan.csv")
if len(plans)!=1:
    raise ValueError("Exactly one simulation plan row is required")
plan=plans[0]
n=int(plan["per_group"]); repetitions=int(plan["repetitions"])
p0=float(plan["usual_probability"]); p1=float(plan["reminder_probability"])
if n<1 or repetitions<1 or not (0<=p0<=1 and 0<=p1<=1):
    raise ValueError("Invalid simulation plan")
rng=random.Random(int(plan["seed"]))
trials=[]
for trial in range(1,repetitions+1):
    usual=sum(rng.random()<p0 for _ in range(n))
    reminder=sum(rng.random()<p1 for _ in range(n))
    trials.append(dict(trial=trial,usual=usual,reminder=reminder,
        difference_points=100*(reminder-usual)/n))
values=sorted(r["difference_points"] for r in trials)
low=values[int(.025*(len(values)-1))]
high=values[int(.975*(len(values)-1))]
summary=[dict(measure="mean_difference_points",value=round(statistics.mean(values),2)),
         dict(measure="central_95_low",value=low),
         dict(measure="central_95_high",value=high),
         dict(measure="reminder_not_higher",value=sum(x<=0 for x in values))]
save_rows("simulation_trials.csv",["trial", "usual", "reminder", "difference_points"],trials)
save_rows("simulation_summary.csv",["measure","value"],summary)
for row in summary: print(f'{row["measure"]}: {row["value"]}')
print("Simulated assumptions; not an estimated treatment effect.")

from collections import Counter
import math
bins = Counter(5*math.floor(r["difference_points"]/5) for r in trials)
frequency = [dict(lower=left, upper=left+5, count=bins[left])
             for left in range(min(bins), max(bins)+1, 5)]
save_rows("simulation_frequency.csv", ["lower", "upper", "count"], frequency)

# Histogram from the saved frequency table; no second simulation.
left = min(f["lower"] for f in frequency)
right = max(f["upper"] for f in frequency)
peak = max(f["count"] for f in frequency)
assumed = 100*(p1-p0)
xmin, xmax = min(left, assumed), max(right, assumed)
def x(value):
    return 60+610*(value-xmin)/max(xmax-xmin, 1)
def y(count):
    return 290-220*count/max(peak, 1)
svg = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 720 370">',
       '<rect width="720" height="370" fill="white"/>',
       '<g font-family="sans-serif" font-size="13">',
       '<text x="60" y="24">Simulated attendance differences</text>',
       '<path d="M60 60 V290 H680" fill="none" stroke="black"/>']
for f in frequency:
    svg.append(f'<rect x="{x(f["lower"])}" y="{y(f["count"])}" '
        f'width="{x(f["upper"])-x(f["lower"])}" '
        f'height="{290-y(f["count"])}" fill="none" stroke="black"/>')
    svg.append(f'<text x="{x(f["lower"])}" y="310">{f["lower"]}</text>')
for count in [0, peak//2, peak]:
    svg.append(f'<text x="12" y="{y(count)+4}">{count}</text>')
svg.append(f'<path d="M{x(assumed)} 45 V290" stroke="black" '
           'stroke-dasharray="5,4"/>')
svg.append(f'<text x="60" y="345">Dashed line: assumed {assumed:g} percentage points</text>')
svg.append('<text x="60" y="363">Reminder minus usual; vertical axis: trial count</text></g></svg>')
with (ROOT/"simulation_histogram.svg").open("x",encoding="utf-8") as stream:
    stream.write("\n".join(svg))
