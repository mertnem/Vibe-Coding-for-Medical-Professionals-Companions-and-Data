import argparse
import hashlib
import json
import platform
from pathlib import Path
import journey_view
import journey_check
from journey_view import read_events, save_csv, render_page
from journey_check import check_events, REPORT_FIELDS

def build_report(source, destination, person=None):
    source, destination = Path(source), Path(destination)
    report = check_events(read_events(source))
    # Validate the complete file BEFORE selecting a person's records.
    selected = [r for r in report if person is None or r["owner_ref"]==person]
    if person is not None and not selected:
        raise ValueError("No records for selected person: " + person)
    counts = dict(input_records=len(report), selected_records=len(selected),
        placed=sum(r["status"]=="placed" for r in selected),
        review=sum(r["status"]=="review" for r in selected))
    modules = [Path(__file__), Path(journey_view.__file__), Path(journey_check.__file__)]
    record = dict(input_file=source.name,
        input_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        program_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in modules},
        python=platform.python_version(), person=person or "all",
        rules="Exactly one visit row, which must pass checks, per encounter; validate before filtering; "
              "review rows retained but not plotted", **counts)
    # The whole report must have a new directory, including on repeat runs.
    destination.mkdir(parents=False,exist_ok=False)
    save_csv(destination/"journey_report.csv",selected,REPORT_FIELDS)
    with (destination/"journey_timeline.html").open("x",encoding="utf-8") as stream:
        stream.write(render_page(selected,"Checked patient-journey timeline"))
    with (destination/"run_record.json").open("x",encoding="utf-8") as stream:
        json.dump(record,stream,indent=2)
    return counts

def main():
    parser = argparse.ArgumentParser(description="Build a synthetic journey report")
    parser.add_argument("input_csv")
    parser.add_argument("new_output_folder")
    parser.add_argument("--person")
    args = parser.parse_args()
    try:
        counts = build_report(args.input_csv,args.new_output_folder,args.person)
    except (ValueError,OSError) as error:
        parser.exit(1,str(error)+"\n")
    for key,value in counts.items():
        print(key + ":",value)
    print("Saved journey_report.csv, journey_timeline.html, run_record.json")

if __name__ == "__main__":
    main()
