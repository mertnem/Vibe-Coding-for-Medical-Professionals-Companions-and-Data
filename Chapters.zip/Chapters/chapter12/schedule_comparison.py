import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent

SCHEMAS = {'clinic_arrivals.csv': ['visit_id', 'arrival_minute', 'service_minutes', 'priority']}

def read_rows(name):
    with (ROOT / name).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream, strict=True)
        if reader.fieldnames != SCHEMAS[name]:
            raise ValueError("Wrong header in " + name)
        rows = list(reader)
    if any(None in row or None in row.values() for row in rows):
        raise ValueError("Malformed CSV row in " + name)
    return rows

from datetime import date as _date


def require_ids(rows, field):
    keys = [r[field] for r in rows]
    if any(not k.strip() or k != k.strip() for k in keys):
        raise ValueError("IDs must be nonblank and unpadded: " + field)
    if len(set(keys)) != len(keys):
        raise ValueError("Duplicate ID: " + field)

def save_rows(name, fields, rows):
    with (ROOT / name).open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

import statistics

visits=read_rows("clinic_arrivals.csv")
require_ids(visits, "visit_id")
for row in visits:
    row["arrival_minute"]=int(row["arrival_minute"])
    row["service_minutes"]=int(row["service_minutes"])
    if row["arrival_minute"]<0 or row["service_minutes"]<=0 or row["priority"] not in {"routine","urgent"}:
        raise ValueError("Invalid visit")
def simulate(rule):
    pending=[dict(r) for r in visits]
    clock=0; records=[]
    while pending:
        ready=[r for r in pending if r["arrival_minute"]<=clock]
        if not ready:
            clock=min(r["arrival_minute"] for r in pending)
            continue
        if rule=="urgent_first":
            key=lambda r:(r["priority"]!="urgent",r["arrival_minute"],r["visit_id"])
        else:
            key=lambda r:(r["arrival_minute"],r["visit_id"])
        chosen=min(ready,key=key)
        start=clock; clock+=chosen["service_minutes"]
        records.append(dict(rule=rule,visit_id=chosen["visit_id"],
            priority=chosen["priority"],arrival=chosen["arrival_minute"],
            start=start,finish=clock,wait=start-chosen["arrival_minute"]))
        pending.remove(chosen)
    return records
def mean_or_blank(values):
    values = list(values)
    return round(statistics.mean(values), 2) if values else ""

details=[]; summary=[]
for rule in ["first_come","urgent_first"]:
    result=simulate(rule); details.extend(result)
    summary.append(dict(rule=rule,
        mean_wait=mean_or_blank(r["wait"] for r in result),
        maximum_wait=max((r["wait"] for r in result), default=""),
        urgent_mean=mean_or_blank(r["wait"] for r in result if r["priority"]=="urgent"),
        routine_mean=mean_or_blank(r["wait"] for r in result if r["priority"]=="routine")))
save_rows("schedule_detail.csv",["rule", "visit_id", "priority", "arrival", "start", "finish", "wait"],details)
save_rows("schedule_summary.csv",["rule", "mean_wait", "maximum_wait", "urgent_mean", "routine_mean"],summary)
for row in summary:
    print(f'{row["rule"]}: mean {row["mean_wait"]}; max {row["maximum_wait"]}; urgent {row["urgent_mean"]}; routine {row["routine_mean"]}')
