import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent

SCHEMAS = {'weekly_followup.csv': ['week', 'completed', 'eligible', 'unresolved', 'provisional']}

def read_rows(name):
    with (ROOT / name).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream, strict=True)
        if reader.fieldnames != SCHEMAS[name]:
            raise ValueError("Wrong header in " + name)
        rows = list(reader)
    if any(None in row or None in row.values() for row in rows):
        raise ValueError("Malformed CSV row in " + name)
    return rows

from datetime import date as _date



def save_rows(name, fields, rows):
    with (ROOT / name).open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

import statistics

report=[]
seen=set()
for row in read_rows("weekly_followup.csv"):
    week=int(row["week"]); complete=int(row["completed"])
    eligible=int(row["eligible"]); unresolved=int(row["unresolved"])
    if week in seen or week<1 or min(complete,eligible,unresolved)<0 or complete>eligible:
        raise ValueError("Invalid weekly counts or duplicate week")
    seen.add(week)
    if row["provisional"] not in {"yes","no"}:
        raise ValueError("Invalid provisional flag")
    report.append(dict(week=week,completed=complete,eligible=eligible,
        rate_percent=round(100*complete/eligible,1) if eligible else "",
        unresolved=unresolved,provisional=row["provisional"]))
report.sort(key=lambda r:r["week"])
save_rows("weekly_followup_report.csv",["week", "completed", "eligible", "rate_percent", "unresolved", "provisional"],report)
final=[r for r in report if r["provisional"]=="no"]
num=sum(r["completed"] for r in final); den=sum(r["eligible"] for r in final)
summary=[dict(measure="final_weeks",value=len(final)),
         dict(measure="final_completed",value=num),
         dict(measure="final_eligible",value=den),
         dict(measure="pooled_final_percent",value=round(100*num/den,1) if den else ""),
         dict(measure="provisional_weeks",value=sum(r["provisional"]=="yes" for r in report))]
save_rows("weekly_summary.csv",["measure","value"],summary)
for row in summary: print(f'{row["measure"]}: {row["value"]}')
