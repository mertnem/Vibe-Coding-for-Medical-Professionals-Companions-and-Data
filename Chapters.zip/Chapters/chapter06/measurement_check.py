import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent

SCHEMAS = {'measurements_to_check.csv': ['record_id', 'event_date', 'value', 'unit']}

def read_rows(name):
    with (ROOT / name).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream, strict=True)
        if reader.fieldnames != SCHEMAS[name]:
            raise ValueError("Wrong header in " + name)
        rows = list(reader)
    if any(None in row or None in row.values() for row in rows):
        raise ValueError("Malformed CSV row in " + name)
    return rows

from datetime import date as _date

def parse_day(value):
    day = _date.fromisoformat(value)
    if day.isoformat() != value:
        raise ValueError("Use exact YYYY-MM-DD dates")
    return day


def save_rows(name, fields, rows):
    with (ROOT / name).open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

from collections import Counter
from datetime import date
import math

rows = read_rows("measurements_to_check.csv")
ids = Counter(r["record_id"].strip() for r in rows)
report = []
for number, row in enumerate(rows, 1):
    reasons = []
    if not row["record_id"].strip() or ids[row["record_id"].strip()] > 1:
        reasons.append("blank or duplicate ID")
    if row["record_id"] != row["record_id"].strip():
        reasons.append("padded ID")
    try:
        parse_day(row["event_date"])
    except ValueError:
        reasons.append("invalid date")
    if not row["value"].strip():
        reasons.append("missing value")
    else:
        try:
            if not math.isfinite(float(row["value"])):
                reasons.append("non-finite value")
        except ValueError:
            reasons.append("not numeric")
    if row["unit"] not in {"C", "F"}:
        reasons.append("unrecognized unit")
    report.append(dict(row, data_row=number,
        status="review" if reasons else "passes checks",
        reason="; ".join(reasons)))
save_rows("measurement_check.csv", SCHEMAS["measurements_to_check.csv"] + ["data_row", "status", "reason"], report)
print("Rows:", len(report))
print("Passes checks:", sum(not r["reason"] for r in report))
print("Review:", sum(bool(r["reason"]) for r in report))
