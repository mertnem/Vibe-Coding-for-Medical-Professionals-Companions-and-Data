import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent

SCHEMAS = {'research_measurements.csv': ['person_ref', 'timepoint', 'value']}

def read_rows(name):
    with (ROOT / name).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream, strict=True)
        if reader.fieldnames != SCHEMAS[name]:
            raise ValueError("Wrong header in " + name)
        rows = list(reader)
    if any(None in row or None in row.values() for row in rows):
        raise ValueError("Malformed CSV row in " + name)
    return rows

from datetime import date as _date



def save_rows(name, fields, rows):
    with (ROOT / name).open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

from collections import defaultdict
import hashlib,json,math,platform,statistics

rows=read_rows("research_measurements.csv")
people=defaultdict(dict)
source_rows={}
for number, row in enumerate(rows, 1):
    key=row["person_ref"]
    visit=row["timepoint"]
    if not key.strip() or key != key.strip() or visit not in {"baseline","followup"} or visit in people[key]:
        raise ValueError("Distinct person-timepoint records required")
    value=float(row["value"]) if row["value"].strip() else None
    if value is not None and not math.isfinite(value):
        raise ValueError("Values must be finite")
    people[key][visit]=value
    source_rows[(key,visit)]=number
derived=[]
for key,values in sorted(people.items()):
    baseline=values.get("baseline")
    followup=values.get("followup")
    complete=baseline is not None and followup is not None
    derived.append(dict(person_ref=key,
        baseline="" if baseline is None else baseline,
        followup="" if followup is None else followup,
        baseline_row=source_rows.get((key,"baseline"),""),
        followup_row=source_rows.get((key,"followup"),""),
        unit="teaching units",paired=int(complete),
        change=followup-baseline if complete else "",
        reason="" if complete else "incomplete pair"))
changes=[r["change"] for r in derived if r["paired"]]
summary=[dict(measure="people",value=len(people)),
         dict(measure="complete_pairs",value=len(changes)),
         dict(measure="mean_change",value=statistics.mean(changes) if changes else ""),
         dict(measure="median_change",value=statistics.median(changes) if changes else "")]
save_rows("derived_changes.csv",["person_ref", "baseline", "followup", "baseline_row", "followup_row", "unit", "paired", "change", "reason"],derived)
save_rows("research_summary.csv",["measure","value"],summary)
manifest={"input_sha256":hashlib.sha256((ROOT/"research_measurements.csv").read_bytes()).hexdigest(),
 "program_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 "python":platform.python_version(),"rule":"followup minus baseline; complete pairs only",
 "output_files":["derived_changes.csv","research_summary.csv"]}
with (ROOT/"run_record.json").open("x",encoding="utf-8") as stream:
    json.dump(manifest,stream,indent=2)
for row in summary:
    print(f'{row["measure"]}: {row["value"]}')
