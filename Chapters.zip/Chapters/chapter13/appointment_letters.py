import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent

SCHEMAS = {'letter_requests.csv': ['appointment_id', 'display_name', 'date', 'time', 'location', 'contact']}

def read_rows(name):
    with (ROOT / name).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream, strict=True)
        if reader.fieldnames != SCHEMAS[name]:
            raise ValueError("Wrong header in " + name)
        rows = list(reader)
    if any(None in row or None in row.values() for row in rows):
        raise ValueError("Malformed CSV row in " + name)
    return rows

from datetime import date as _date


def require_ids(rows, field):
    keys = [r[field] for r in rows]
    if any(not k.strip() or k != k.strip() for k in keys):
        raise ValueError("IDs must be nonblank and unpadded: " + field)
    if len(set(keys)) != len(keys):
        raise ValueError("Duplicate ID: " + field)

def save_rows(name, fields, rows):
    with (ROOT / name).open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

from datetime import datetime
from html import escape

rows=read_rows("letter_requests.csv")
require_ids(rows, "appointment_id")
sections=[]; report=[]
for row in rows:
    issues=[name for name in ["display_name","date","time","location","contact"] if not row[name].strip()]
    try:
        supplied = row["date"] + " " + row["time"]
        day=datetime.strptime(supplied,"%Y-%m-%d %H:%M")
        if day.strftime("%Y-%m-%d %H:%M") != supplied:
            raise ValueError("Use YYYY-MM-DD and HH:MM")
    except ValueError:
        issues.append("invalid date or time")
    status="hold" if issues else "generated"
    report.append(dict(appointment_id=row["appointment_id"],status=status,
        reason="; ".join(issues)))
    if issues:
        continue
    fields={k:escape(v) for k,v in row.items()}
    sections.append("<section><p>SYNTHETIC TEACHING EXAMPLE</p><h1>Appointment details</h1>"+
        "<p>"+fields["display_name"]+"</p><p>"+fields["date"]+" at "+fields["time"]+
        "</p><p>Location: "+fields["location"]+"</p><p>Questions or changes: "+
        fields["contact"]+"</p><p>Please check these details and contact the office "+
        "if anything is incorrect.</p><p>Reference: "+fields["appointment_id"]+"</p></section>")
save_rows("letter_build_report.csv",["appointment_id", "status", "reason"],report)
page='<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Teaching appointment pack</title>'
page+='<style>body{font:20px system-ui;max-width:720px;margin:auto}section{padding:30px;border-bottom:1px solid #aaa;overflow-wrap:anywhere}h1{line-height:1.2}@page{size:letter;margin:18mm}@media print{body{font-size:14pt;max-width:none}section{padding:12mm;break-after:page;break-inside:avoid}section:last-child{break-after:auto}}</style>'
with (ROOT/"appointment_letters.html").open("x",encoding="utf-8") as stream:
    stream.write(page+("\n".join(sections) if sections else "<p>No letters generated.</p>")+"</html>")
print("Letters generated:",len(sections))
print("Held for missing or invalid details:",sum(r["status"]=="hold" for r in report))
print("No messages sent.")
