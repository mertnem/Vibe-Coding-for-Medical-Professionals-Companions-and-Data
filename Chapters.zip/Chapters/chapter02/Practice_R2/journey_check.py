from collections import Counter, defaultdict
from datetime import date
from pathlib import Path
from journey_view import FIELDS, KINDS, read_events, save_csv, render_page

REPORT_FIELDS = FIELDS + ["data_row", "owner_ref", "status", "issues"]

def check_events(rows):
    ids = Counter(r["event_id"].strip() for r in rows)
    issues = [[] for _ in rows]
    days = []
    visits = defaultdict(list)
    for i, row in enumerate(rows):
        for field in FIELDS:
            if not row[field].strip():
                issues[i].append("missing " + field)
        for field in ["event_id", "person_ref", "encounter_id"]:
            if row[field] != row[field].strip():
                issues[i].append("padded " + field)
        key = row["event_id"].strip()
        if key and ids[key] > 1:
            issues[i].append("duplicate event_id")
        try:
            day = date.fromisoformat(row["event_date"])
            if day.isoformat() != row["event_date"]:
                raise ValueError()
        except ValueError:
            day = None
            if row["event_date"].strip():
                issues[i].append("invalid event_date")
        days.append(day)
        if row["event_type"] not in KINDS:
            issues[i].append("unrecognized event_type")
        if row["event_type"]=="visit" and row["encounter_id"].strip():
            visits[row["encounter_id"]].append(i)
    # An encounter needs one unambiguous, dated, otherwise valid visit.
    anchors = {}
    for encounter, positions in visits.items():
        if len(positions)!=1:
            for i in positions:
                issues[i].append("multiple visits for encounter")
        else:
            i = positions[0]
            if not issues[i]:
                anchors[encounter] = i
    report = []
    for i, row in enumerate(rows):
        anchor = anchors.get(row["encounter_id"])
        owner = row["person_ref"] or "(unassigned)"
        if anchor is None:
            if row["event_type"]!="visit" or not issues[i]:
                issues[i].append("no valid visit for encounter")
        else:
            owner = rows[anchor]["person_ref"]
            if row["person_ref"] != owner:
                issues[i].append("person differs from visit")
            if days[i] is not None and days[i] < days[anchor]:
                issues[i].append("event before visit")
        report.append(dict(row, data_row=i+1, owner_ref=owner,
            status="review" if issues[i] else "placed",
            issues="; ".join(issues[i])))
    return report

def main():
    root = Path(__file__).resolve().parent
    report = check_events(read_events(root/"journey_problem.csv"))
    save_csv(root/"journey_review.csv",report,REPORT_FIELDS)
    with (root/"journey_checked.html").open("x",encoding="utf-8") as stream:
        stream.write(render_page(report,"Checked patient-journey timeline"))
    print("Input records:",len(report))
    print("Placed:",sum(r["status"]=="placed" for r in report))
    print("For review:",sum(r["status"]=="review" for r in report))
    print("Saved journey_checked.html and journey_review.csv")

if __name__ == "__main__":
    main()
