import csv
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
with (ROOT/"package_files.csv").open(newline="",encoding="utf-8") as stream:
    reader = csv.DictReader(stream, strict=True)
    if reader.fieldnames != ["filename", "purpose"]:
        raise ValueError("Wrong package-list header")
    items = list(reader)
if not items or any(None in r or None in r.values() for r in items):
    raise ValueError("A nonempty, well-formed package list is required")
names = [r["filename"] for r in items]
if len(set(names))!=len(names) or set(names)&{"manifest.json","RUN.txt"}:
    raise ValueError("Duplicate or reserved package filename")
manifest = []
for item in items:
    name = item["filename"]
    if not name.strip() or name != name.strip() or Path(name).name!=name:
        raise ValueError("Use simple filenames from this folder")
    data = (ROOT/name).read_bytes()
    manifest.append(dict(filename=name,purpose=item["purpose"],
        bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
instructions = """SYNTHETIC PATIENT-JOURNEY DEMONSTRATION
Release: medical-teaching-2026-09-19-r3.
The manifest identifies the exact supplied program versions.
Extract all files into a fresh folder.
Ask ChatGPT with Python execution enabled to run:
python3 journey_report.py journey_problem.csv first_run
Compare the counts with expected_summary.txt.
Open first_run/journey_timeline.html and inspect all three panels.
Check all 18 CSV rows, including the six retained for review.
For the clean example, use journey_demo.csv and a different new output folder.
The three program files must remain together.
These files are teaching examples, not approved clinical software.
"""
with zipfile.ZipFile(ROOT/"journey_demo_package.zip","x",zipfile.ZIP_DEFLATED) as package:
    for item in items:
        package.write(ROOT/item["filename"],arcname=item["filename"])
    package.writestr("manifest.json",json.dumps(manifest,indent=2))
    package.writestr("RUN.txt",instructions)
print("Package files:",len(items)+2)
print("Source files:",len(items))
print("Saved journey_demo_package.zip")
