import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent

SCHEMAS = {'score_cases.csv': ['case_id', 'duration', 'task_count', 'support_present']}

def read_rows(name):
    with (ROOT / name).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream, strict=True)
        if reader.fieldnames != SCHEMAS[name]:
            raise ValueError("Wrong header in " + name)
        rows = list(reader)
    if any(None in row or None in row.values() for row in rows):
        raise ValueError("Malformed CSV row in " + name)
    return rows

from datetime import date as _date


def require_ids(rows, field):
    keys = [r[field] for r in rows]
    if any(not k.strip() or k != k.strip() for k in keys):
        raise ValueError("IDs must be nonblank and unpadded: " + field)
    if len(set(keys)) != len(keys):
        raise ValueError("Duplicate ID: " + field)

def save_rows(name, fields, rows):
    with (ROOT / name).open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

import math

report = []
rows = read_rows("score_cases.csv")
require_ids(rows, "case_id")
for row in rows:
    issues = []
    duration = tasks = None
    try:
        duration = float(row["duration"])
        if not math.isfinite(duration) or duration < 0:
            issues.append("invalid duration")
    except ValueError:
        issues.append("missing or nonnumeric duration")
    try:
        tasks = int(row["task_count"])
        if tasks < 0:
            issues.append("negative task count")
    except ValueError:
        issues.append("invalid task count")
    if row["support_present"] not in {"yes","no"}:
        issues.append("invalid support value")
    d = t = support = total = ""
    if not issues:
        d = 0 if duration < 5 else 1 if duration < 10 else 2
        t = 0 if tasks <= 2 else 1 if tasks <= 5 else 2
        support = int(row["support_present"] == "no")
        total = d+t+support
    report.append(dict(case_id=row["case_id"],duration_points=d,
        task_points=t,support_points=support,total=total,
        status="review" if issues else "calculated",
        reason="; ".join(issues)))
save_rows("teaching_score_report.csv",["case_id", "duration_points", "task_points", "support_points", "total", "status", "reason"],report)
for row in report:
    print(row["case_id"], row["total"] if row["status"]=="calculated" else row["reason"])
print("Fictional classroom rule; no clinical interpretation.")
