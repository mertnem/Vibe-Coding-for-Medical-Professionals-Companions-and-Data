"""Build a fictional expected-count explorer; no real test is evaluated."""
import csv
import html
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
N = 10000
sensitivity = 0.90
specificity = 0.95
# This one model supplies the CSV calculation, page labels, and JavaScript.
MODEL = dict(n=N, sensitivity=sensitivity, specificity=specificity)
if (isinstance(N, bool) or not isinstance(N, int) or N <= 0 or
        any(not math.isfinite(x) or not 0 <= x <= 1
            for x in (sensitivity, specificity))):
    raise ValueError("Use a positive population and probabilities from 0 to 1")


def read_rows(name):
    with (ROOT / name).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream, strict=True)
        if reader.fieldnames != ["prevalence_percent"]:
            raise ValueError("Wrong header in " + name)
        rows = list(reader)
    if any(None in row or None in row.values() for row in rows):
        raise ValueError("Malformed CSV row in " + name)
    return rows


def expected(prevalence):
    condition = MODEL["n"] * prevalence
    tp = condition * MODEL["sensitivity"]
    fn = condition - tp
    fp = (MODEL["n"] - condition) * (1 - MODEL["specificity"])
    tn = MODEL["n"] - condition - fp
    return tp, fp, fn, tn


report = []
for row in read_rows("test_scenarios.csv"):
    prevalence = float(row["prevalence_percent"]) / 100
    if not math.isfinite(prevalence) or not 0 <= prevalence <= 1:
        raise ValueError("Prevalence must be between 0 and 100 percent")
    tp, fp, fn, tn = expected(prevalence)
    report.append(dict(prevalence_percent=prevalence * 100,
        tp=round(tp, 6), fp=round(fp, 6), fn=round(fn, 6), tn=round(tn, 6),
        ppv_percent=round(100 * tp / (tp + fp), 1) if tp + fp else ""))

page = '''<!doctype html><html lang="en"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Predictive-value classroom explorer</title>
<style>
body{font:20px system-ui;max-width:800px;margin:32px auto;padding:0 20px}
h1{font-size:30px;line-height:1.2}p{line-height:1.5}
input,button{font:inherit;padding:6px}input{width:110px}
button{margin:8px 0}a:focus,input:focus,button:focus{outline:3px solid #175078}
.scroll{overflow-x:auto}table{border-collapse:collapse;width:100%}
td,th{padding:12px;border:1px solid #aaa;text-align:right}
th:first-child{text-align:left}thead,tfoot{background:#f1f5f8}
.small{font-size:16px}.ppv{font-size:25px;font-weight:600}
</style><main><h1>Predictive-value classroom explorer</h1>
<p id="assumptions">Fictional expected counts in __N__ people.<br>
Sensitivity __SENS__%; specificity __SPEC__%. These are assumptions,
not evidence about a real test.</p>
<label for="p">Prevalence (%): </label>
<input id="p" type="number" min="0" max="100" step="any" value="1">
<button id="go" type="button">Calculate</button>
<div id="result" aria-live="polite"></div>
<p class="small">Expected counts need not be whole numbers. Changing this
page does not change the separately saved scenario CSV.</p></main>
<script>
const model = __MODEL__;
function update(){
 const raw=document.getElementById("p").value.trim();
 const p=Number(raw)/100;
 const result=document.getElementById("result");
 if(raw===""||!Number.isFinite(p)||p<0||p>1){
  result.textContent="Enter 0 to 100.";return;
 }
 const condition=model.n*p;
 const tp=condition*model.sensitivity, fn=condition-tp;
 const fp=(model.n-condition)*(1-model.specificity);
 const tn=model.n-condition-fp;
 const ppv=tp+fp ? (100*tp/(tp+fp)).toFixed(1)+"%" : "undefined";
 const number=x=>x.toFixed(1);
 const cell=(id,x)=>'<td id="'+id+'">'+number(x)+'</td>';
 result.innerHTML='<p class="ppv">Positive predictive value: <span id="ppv">'+
 ppv+'</span></p><div class="scroll"><table><caption>Expected counts</caption>'+
 '<thead><tr><th scope="col">Test result</th><th scope="col">Condition present</th>'+
 '<th scope="col">Condition absent</th><th scope="col">Total</th></tr></thead>'+
 '<tbody><tr><th scope="row">Positive</th>'+cell('tp',tp)+cell('fp',fp)+
 cell('positive-total',tp+fp)+'</tr><tr><th scope="row">Negative</th>'+
 cell('fn',fn)+cell('tn',tn)+cell('negative-total',fn+tn)+'</tr></tbody>'+
 '<tfoot><tr><th scope="row">Total</th>'+cell('condition-total',tp+fn)+
 cell('absent-total',fp+tn)+cell('population-total',model.n)+
 '</tr></tfoot></table></div>';
}
document.getElementById("go").addEventListener("click",update);
document.getElementById("p").addEventListener("input",update);update();
</script></html>'''
page = (page.replace("__N__", f'{MODEL["n"]:,}')
        .replace("__SENS__", f'{100 * MODEL["sensitivity"]:g}')
        .replace("__SPEC__", f'{100 * MODEL["specificity"]:g}')
        .replace("__MODEL__", json.dumps(MODEL, allow_nan=False)))
outputs = ["test_scenarios_report.csv", "predictive_value.html"]
if any((ROOT / name).exists() for name in outputs):
    raise FileExistsError("Use a fresh copy of the chapter folder")
with (ROOT / outputs[0]).open("x", newline="", encoding="utf-8") as stream:
    writer = csv.DictWriter(stream, fieldnames=["prevalence_percent", "tp",
        "fp", "fn", "tn", "ppv_percent"])
    writer.writeheader()
    writer.writerows(report)
with (ROOT / outputs[1]).open("x", encoding="utf-8") as stream:
    stream.write(page)
for row in report:
    value = (str(row["ppv_percent"]) + "%") if row["ppv_percent"] != "" else "undefined"
    print(f'Prevalence {row["prevalence_percent"]:g}%: PPV {value}')
