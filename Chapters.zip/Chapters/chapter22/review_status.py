import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent

SCHEMAS = {'review_register.csv': ['artifact', 'current_version', 'reviewed_version', 'decision', 'reviewer_role', 'valid_until']}

def read_rows(name):
    with (ROOT / name).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream, strict=True)
        if reader.fieldnames != SCHEMAS[name]:
            raise ValueError("Wrong header in " + name)
        rows = list(reader)
    if any(None in row or None in row.values() for row in rows):
        raise ValueError("Malformed CSV row in " + name)
    return rows

from datetime import date as _date

def parse_day(value):
    day = _date.fromisoformat(value)
    if day.isoformat() != value:
        raise ValueError("Use exact YYYY-MM-DD dates")
    return day


def save_rows(name, fields, rows):
    with (ROOT / name).open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

from datetime import date

AS_OF=date(2026,9,17)
RULE_VERSION = "review-register-v1"
required={"Specification","Program","Tests","Data handling","User guide"}
rows=read_rows("review_register.csv")
names=[r["artifact"] for r in rows]
if len(set(names))!=len(names) or set(names)!=required:
    raise ValueError("Exactly one row for every required artifact")
report=[]
for row in rows:
    issues=[]
    if row["decision"]!="accepted":
        issues.append("review not accepted")
    if (not row["current_version"].strip() or not row["reviewed_version"].strip()
            or row["current_version"]!=row["reviewed_version"]):
        issues.append("missing or mismatched version")
    if not row["reviewer_role"].strip():
        issues.append("reviewer missing")
    try:
        if parse_day(row["valid_until"])<AS_OF:
            issues.append("review expired")
    except ValueError:
        issues.append("invalid review date")
    report.append(dict(artifact=row["artifact"],as_of=AS_OF.isoformat(),
        rule_version=RULE_VERSION,
        current_version=row["current_version"],reviewed_version=row["reviewed_version"],
        status="blocker" if issues else "record complete",
        reason="; ".join(issues)))
save_rows("review_status_report.csv",["artifact", "as_of", "rule_version",
    "current_version", "reviewed_version", "status", "reason"],report)
print("As of:",AS_OF)
print("Rule version:",RULE_VERSION)
print("Records complete:",sum(r["status"]=="record complete" for r in report))
print("Records with blockers:",sum(r["status"]=="blocker" for r in report))
print("This checks recorded review completeness, not clinical approval.")
