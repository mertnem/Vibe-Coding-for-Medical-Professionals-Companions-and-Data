import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent

SCHEMAS = {'district_outreach.csv': ['district', 'age_band', 'reached', 'eligible']}

def read_rows(name):
    with (ROOT / name).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream, strict=True)
        if reader.fieldnames != SCHEMAS[name]:
            raise ValueError("Wrong header in " + name)
        rows = list(reader)
    if any(None in row or None in row.values() for row in rows):
        raise ValueError("Malformed CSV row in " + name)
    return rows

from datetime import date as _date



def save_rows(name, fields, rows):
    with (ROOT / name).open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

from collections import defaultdict

groups=defaultdict(dict)
for row in read_rows("district_outreach.csv"):
    band=row["age_band"]; district=row["district"]
    if not district.strip() or district != district.strip():
        raise ValueError("Nonblank unpadded district required")
    reached=int(row["reached"]); eligible=int(row["eligible"])
    if band not in {"under65","65plus"} or band in groups[district]:
        raise ValueError("Two distinct age bands per district required")
    if eligible<=0 or not 0<=reached<=eligible:
        raise ValueError("Invalid counts")
    groups[district][band]=(reached,eligible)
report=[]
for district,bands in sorted(groups.items()):
    if set(bands)!={"under65","65plus"}:
        raise ValueError("Missing age band")
    reached=sum(x[0] for x in bands.values())
    eligible=sum(x[1] for x in bands.values())
    rates={band:100*n/d for band,(n,d) in bands.items()}
    report.append(dict(district=district,reached=reached,eligible=eligible,
        crude_percent=round(100*reached/eligible,1),
        standardized_percent=round(.5*rates["under65"]+.5*rates["65plus"],1),
        weight_under65=.5,weight_65plus=.5))
save_rows("district_rates.csv",["district", "reached", "eligible", "crude_percent", "standardized_percent", "weight_under65", "weight_65plus"],report)
for row in report:
    print(f'{row["district"]}: crude {row["crude_percent"]}%, standardized {row["standardized_percent"]}%')
