import csv
import tempfile
from pathlib import Path
from journey_view import read_events, render_page
from journey_check import check_events
from journey_report import build_report

ROOT = Path(__file__).resolve().parent
clean = read_events(ROOT/"journey_demo.csv")
problem = read_events(ROOT/"journey_problem.csv")
results = []

def require(condition, message):
    if not condition:
        raise AssertionError(message)

def trial(name, operation):
    try:
        operation()
    except Exception as error:
        results.append(dict(test=name,status="FAIL",detail=str(error)))
    else:
        results.append(dict(test=name,status="PASS",detail=""))

def require_retained(source, report):
    require(len(report) == len(source), "All input records must remain")
    require({r["data_row"] for r in report} == set(range(1, len(source)+1)),
            "Source-row identities were lost or duplicated")
    by_row = {r["data_row"]: r for r in report}
    for number, original in enumerate(source, 1):
        require(all(by_row[number][key] == value
                    for key, value in original.items()),
                "Source values changed in row " + str(number))

def counts_test():
    report = check_events(clean)
    require_retained(clean, report)
    require(len(report)==18 and all(r["status"]=="placed" for r in report),
            "Clean file must place all 18 events")

def problems_test():
    report = check_events(problem)
    require_retained(problem, report)
    expected = {2:"duplicate event_id",3:"event before visit",
                8:"missing event_date",11:"invalid event_date",
                14:"duplicate event_id",18:"person differs from visit"}
    require(len(report)==18, "All 18 input records must remain")
    require({r["data_row"] for r in report}==set(range(1,19)),
            "Input row identities were lost")
    actual = {r["data_row"]:r["issues"] for r in report if r["status"]=="review"}
    require(actual==expected,"Wrong review rows or reasons")
    require(report[17]["owner_ref"]=="P03" and report[17]["person_ref"]=="P01",
            "Person mismatch must stay visible")

def duplicate_test():
    rows = [dict(r) for r in problem]
    rows[13]["event_id"] = "E14"
    report = check_events(rows)
    require_retained(rows, report)
    require(sum(r["status"]=="review" for r in report)==4,
            "Correcting duplicate ID should clear two rows")

def same_day_test():
    rows = [dict(r) for r in clean]
    rows[2]["event_date"] = rows[0]["event_date"]
    report = check_events(rows)
    require_retained(rows, report)
    require(report[2]["status"]=="placed",
            "Same-day follow-up is permitted")

def missing_anchor_test():
    rows = [r for r in clean if r["event_id"]!="E16"]
    report = check_events(rows)
    require_retained(rows, report)
    require(len(report) == 17, "Removing E16 leaves 17 retained records")
    dependent = [r for r in report if r["encounter_id"] == "C06"]
    require({r["event_id"] for r in dependent} == {"E17", "E18"},
            "Both dependent identities E17 and E18 must remain")
    require(all(r["status"] == "review" for r in dependent),
            "Dependent events require a visit")

def multiple_anchor_test():
    rows = [dict(r) for r in clean] + [dict(clean[15],event_id="E19")]
    report = check_events(rows)
    require_retained(rows, report)
    require(len(report)==19, "All 19 rows must remain")
    require({r["event_id"] for r in report if r["encounter_id"]=="C06"}==
            {"E16","E17","E18","E19"}, "All four encounter identities must remain")
    require(sum(r["status"]=="review" for r in report if r["encounter_id"]=="C06")==4,
            "Ambiguous encounter must withhold all four rows")

def header_test():
    with tempfile.TemporaryDirectory() as folder:
        path = Path(folder)/"bad.csv"
        path.write_text("wrong,header\n",encoding="utf-8")
        try:
            read_events(path)
        except ValueError:
            return
        raise AssertionError("Bad header accepted")

def order_test():
    def key(rows):
        report = check_events(rows)
        require_retained(rows, report)
        return {(r["event_id"],r["encounter_id"]):
                (r["status"],r["issues"],r["owner_ref"]) for r in report}
    require(key(problem)==key(list(reversed(problem))),
            "Classification changed when rows moved")

def html_test():
    rows = [dict(r) for r in clean]
    rows[0]["detail"] = "<b>Teaching & example</b>"
    page = render_page(check_events(rows))
    require("&lt;b&gt;Teaching &amp; example&lt;/b&gt;" in page
            and "<b>Teaching & example</b>" not in page,
            "Supplied details interpreted as HTML")

def selection_test():
    with tempfile.TemporaryDirectory() as folder:
        target = Path(folder)/"P03"
        counts = build_report(ROOT/"journey_problem.csv",target,"P03")
        require(counts==dict(input_records=18,selected_records=6,placed=4,review=2),
                "Wrong selected counts")
        with (target/"journey_report.csv").open() as stream:
            rows = list(csv.DictReader(stream))
        require(any(r["event_id"]=="E18" and r["person_ref"]=="P01" for r in rows),
                "Selection lost the mismatched source record")

def overwrite_test():
    with tempfile.TemporaryDirectory() as folder:
        target = Path(folder)/"existing"
        build_report(ROOT/"journey_problem.csv",target)
        before = {p.name:p.read_bytes() for p in target.iterdir()}
        try:
            build_report(ROOT/"journey_problem.csv",target)
        except FileExistsError:
            pass
        else:
            raise AssertionError("Existing output folder accepted")
        require(before=={p.name:p.read_bytes() for p in target.iterdir()},
                "Earlier output changed")

def repeat_test():
    with tempfile.TemporaryDirectory() as folder:
        a,b = Path(folder)/"first",Path(folder)/"second"
        build_report(ROOT/"journey_problem.csv",a)
        build_report(ROOT/"journey_problem.csv",b)
        require({p.name:p.read_bytes() for p in a.iterdir()}==
                {p.name:p.read_bytes() for p in b.iterdir()},
                "Repeated outputs differ")

for name,operation in [
    ("clean_counts",counts_test),("problem_reasons",problems_test),
    ("duplicate_correction",duplicate_test),("same_day",same_day_test),
    ("missing_visit",missing_anchor_test),("multiple_visits",multiple_anchor_test),
    ("bad_header",header_test),("row_order",order_test),
    ("escaped_HTML",html_test),("person_selection",selection_test),
    ("no_overwrite",overwrite_test),("repeat_run",repeat_test)]:
    trial(name,operation)

with (ROOT/"journey_tests.csv").open("x",newline="",encoding="utf-8") as stream:
    writer = csv.DictWriter(stream,fieldnames=["test","status","detail"])
    writer.writeheader()
    writer.writerows(results)
print("Passed:",sum(r["status"]=="PASS" for r in results))
print("Failed:",sum(r["status"]=="FAIL" for r in results))
if any(r["status"]=="FAIL" for r in results):
    raise SystemExit(1)
