"""Ten named checks for the book's unchanged journey_large.csv fixture.

These fixed expectations belong to this supplied synthetic dataset, not
arbitrary journey files. No test edits the original input or program files.
Browser interaction and performance are separate acceptance checks.
"""
import argparse
from collections import Counter, defaultdict
import csv
from datetime import date
import hashlib
import json
from pathlib import Path

from journey_view import FIELDS, read_events
from journey_check import check_events
from journey_report import build_report


def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as stream:
        return list(csv.DictReader(stream, strict=True))


def save_input(path: Path, rows: list[dict[str, str]]) -> None:
    with path.open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)


def fingerprint(folder: Path) -> dict[str, str]:
    return {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
            for p in folder.iterdir() if p.is_file()}


def run_tests(source: Path, destination: Path) -> list[dict[str, str]]:
    source, destination = Path(source), Path(destination)
    rows = read_events(source)
    before = hashlib.sha256(source.read_bytes()).hexdigest()
    destination.mkdir(parents=False, exist_ok=False)
    results = []

    def test(name, action):
        try:
            action()
            results.append(dict(test=name, status="PASS", detail=""))
        except Exception as error:
            results.append(dict(test=name, status="FAIL",
                                detail=type(error).__name__+": "+str(error)))

    def shape_and_ids():
        assert len(rows) == 12000, "Expected 12,000 source rows"
        assert len({r["event_id"] for r in rows}) == 12000, "Event IDs not unique"
        assert set(rows[0]) == set(FIELDS), "Wrong source fields"

    def populations_and_kinds():
        people, encounters = defaultdict(set), defaultdict(Counter)
        for r in rows:
            people[r["person_ref"]].add(r["encounter_id"])
            encounters[r["encounter_id"]][r["event_type"]] += 1
        assert len(people) == 1000 and len(encounters) == 3000
        assert all(len(group) == 3 for group in people.values())
        expected = Counter(visit=1, test=1, measurement=1, followup=1)
        assert all(group == expected for group in encounters.values())

    def date_range():
        days = [date.fromisoformat(r["event_date"]) for r in rows]
        assert min(days) == date(2026, 1, 1)
        assert max(days) == date(2026, 8, 29)

    def clean_classification():
        report = check_events(rows)
        assert len(report) == 12000
        assert Counter(r["status"] for r in report) == Counter(placed=12000)
        for n, (original, result) in enumerate(zip(rows, report), 1):
            assert {k: result[k] for k in FIELDS} == original
            assert result["data_row"] == n
            assert result["owner_ref"] == original["person_ref"]
            assert result["issues"] == ""

    def full_saved_report():
        target = destination / "all_people"
        counts = build_report(source, target)
        assert counts == dict(input_records=12000, selected_records=12000,
                              placed=12000, review=0)
        saved = load_csv(target / "journey_report.csv")
        assert len(saved) == 12000
        expected = Counter(tuple(r[k] for k in FIELDS) for r in rows)
        actual = Counter(tuple(r[k] for k in FIELDS) for r in saved)
        assert actual == expected, "Lost, duplicated, or changed source values"
        record = json.loads((target / "run_record.json").read_text())
        assert record["input_sha256"] == before
        assert (target / "journey_timeline.html").stat().st_size > 0

    def selected_person():
        target = destination / "P0001"
        counts = build_report(source, target, "P0001")
        assert counts == dict(input_records=12000, selected_records=12,
                              placed=12, review=0)
        saved = load_csv(target / "journey_report.csv")
        assert len(saved) == 12
        assert {r["event_id"] for r in saved} == {f"E{i:06d}" for i in range(1, 13)}
        assert {r["person_ref"] for r in saved} == {"P0001"}

    def row_order():
        keys = FIELDS+["owner_ref", "status", "issues"]
        def by_id(report):
            return {r["event_id"]: tuple(r[k] for k in keys) for r in report}
        assert by_id(check_events(rows)) == by_id(check_events(list(reversed(rows))))

    def missing_date():
        changed = [dict(r) for r in rows]
        target = next(r for r in changed if r["event_id"] == "E000002")
        target["event_date"] = ""
        report = check_events(changed)
        assert len(report) == 12000
        assert Counter(r["status"] for r in report) == Counter(placed=11999, review=1)
        review = [r for r in report if r["status"] == "review"]
        assert len(review) == 1 and review[0]["event_id"] == "E000002"
        assert review[0]["issues"] == "missing event_date"

    def duplicate_before_selection():
        changed = [dict(r) for r in rows]
        next(r for r in changed if r["event_id"] == "E000014")["event_id"] = "E000002"
        source_copy = destination / "duplicate.csv"
        save_input(source_copy, changed)
        report = check_events(changed)
        review = [r for r in report if r["status"] == "review"]
        assert len(report) == 12000 and len(review) == 2
        assert {r["event_id"] for r in review} == {"E000002"}
        assert {r["person_ref"] for r in review} == {"P0001", "P0002"}
        assert all(r["issues"] == "duplicate event_id" for r in review)
        target = destination / "duplicate_P0001"
        counts = build_report(source_copy, target, "P0001")
        assert counts == dict(input_records=12000, selected_records=12,
                              placed=11, review=1)

    def protected_repeat():
        target = destination / "protected"
        build_report(source, target, "P0001")
        saved = fingerprint(target)
        try:
            build_report(source, target, "P0001")
        except FileExistsError:
            pass
        else:
            raise AssertionError("An existing destination was accepted")
        assert fingerprint(target) == saved, "Earlier output changed"
        assert hashlib.sha256(source.read_bytes()).hexdigest() == before

    for name, action in [
        ("shape_and_ids", shape_and_ids),
        ("populations_and_kinds", populations_and_kinds),
        ("date_range", date_range),
        ("clean_classification", clean_classification),
        ("full_saved_report", full_saved_report),
        ("selected_person", selected_person),
        ("row_order", row_order),
        ("missing_date", missing_date),
        ("duplicate_before_selection", duplicate_before_selection),
        ("protected_repeat", protected_repeat),
    ]:
        test(name, action)
    with (destination / "journey_large_tests.csv").open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=["test", "status", "detail"])
        writer.writeheader()
        writer.writerows(results)
    return results


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_csv")
    parser.add_argument("new_output_folder")
    args = parser.parse_args()
    try:
        results = run_tests(Path(args.input_csv), Path(args.new_output_folder))
    except (ValueError, OSError) as error:
        parser.exit(1, str(error)+"\n")
    passed = sum(r["status"] == "PASS" for r in results)
    failed = len(results)-passed
    print("Passed:", passed)
    print("Failed:", failed)
    raise SystemExit(1 if failed else 0)


if __name__ == "__main__":
    main()
