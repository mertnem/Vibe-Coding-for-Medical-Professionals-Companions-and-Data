import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent

SCHEMAS = {'waiting_times.csv': ['month', 'wait_days']}

def read_rows(name):
    with (ROOT / name).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream, strict=True)
        if reader.fieldnames != SCHEMAS[name]:
            raise ValueError("Wrong header in " + name)
        rows = list(reader)
    if any(None in row or None in row.values() for row in rows):
        raise ValueError("Malformed CSV row in " + name)
    return rows

from datetime import date as _date



def save_rows(name, fields, rows):
    with (ROOT / name).open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

from collections import defaultdict
from datetime import datetime
import math, statistics

groups = defaultdict(list)
for row in read_rows("waiting_times.csv"):
    month = row["month"]
    if datetime.strptime(month, "%Y-%m").strftime("%Y-%m") != month:
        raise ValueError("Use YYYY-MM")
    if not month.startswith("2026-"):
        raise ValueError("This report covers 2026")
    value = float(row["wait_days"])
    if not math.isfinite(value) or value < 0:
        raise ValueError("Waiting times must be finite and nonnegative")
    groups[month].append(value)
summary = []
for m in range(1,13):
    key = f"2026-{m:02}"
    values = groups[key]
    summary.append(dict(month=key, count=len(values),
        median_days=statistics.median(values) if values else ""))
save_rows("monthly_waits.csv", ["month","count","median_days"], summary)
maximum = max([r["median_days"] for r in summary if r["count"]] or [1])
top = max(5, math.ceil(maximum / 5) * 5)
svg = ['<svg xmlns="http://www.w3.org/2000/svg" width="720" height="360" viewBox="0 0 720 360">',
       '<rect width="720" height="360" fill="white"/>',
       '<text x="50" y="25">Synthetic median waiting time: 2026</text>']
for value in range(0,top+1,5):
    y = 280 - 220*value/top
    svg.append(f'<path d="M50 {y} H690" stroke="#ddd"/>')
    svg.append(f'<text x="15" y="{y+4}">{value}</text>')
previous = None
for i,row in enumerate(summary):
    x = 65 + 55*i
    svg.append(f'<text x="{x-7}" y="305">{i+1}</text>')
    svg.append(f'<text x="{x-10}" y="325">n={row["count"]}</text>')
    if not row["count"]:
        previous = None
        continue
    y = 280 - 220*row["median_days"]/top
    if previous:
        svg.append(f'<path d="M{previous[0]} {previous[1]} L{x} {y}" stroke="#175078" stroke-width="2"/>')
    svg.append(f'<circle cx="{x}" cy="{y}" r="4" fill="#175078"/>')
    previous = (x,y)
svg.append('<text x="270" y="350">Month; vertical scale in days</text></svg>')
(ROOT/"waiting_time_report.svg").write_text("\n".join(svg),encoding="utf-8")
print("Observed months:", sum(r["count"] > 0 for r in summary))
print("Missing months:", ", ".join(r["month"] for r in summary if not r["count"]))
print("Saved monthly_waits.csv and waiting_time_report.svg")
