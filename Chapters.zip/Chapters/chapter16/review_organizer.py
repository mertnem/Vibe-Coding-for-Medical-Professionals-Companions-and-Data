import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent

SCHEMAS = {'citations.csv': ['record_id', 'study_id', 'title', 'year', 'decision', 'reason']}

def read_rows(name):
    with (ROOT / name).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream, strict=True)
        if reader.fieldnames != SCHEMAS[name]:
            raise ValueError("Wrong header in " + name)
        rows = list(reader)
    if any(None in row or None in row.values() for row in rows):
        raise ValueError("Malformed CSV row in " + name)
    return rows

from datetime import date as _date


def require_ids(rows, field):
    keys = [r[field] for r in rows]
    if any(not k.strip() or k != k.strip() for k in keys):
        raise ValueError("IDs must be nonblank and unpadded: " + field)
    if len(set(keys)) != len(keys):
        raise ValueError("Duplicate ID: " + field)

def save_rows(name, fields, rows):
    with (ROOT / name).open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

from collections import defaultdict,Counter

rows = read_rows("citations.csv")
require_ids(rows, "record_id")
groups = defaultdict(list)
for row in rows:
    if not row["study_id"].strip() or row["study_id"] != row["study_id"].strip() or row["decision"] not in {"include","exclude","pending"}:
        raise ValueError("Study ID and approved decision required")
    if row["decision"]=="exclude" and not row["reason"].strip():
        raise ValueError("Exclusions require a reason")
    groups[row["study_id"]].append(row)
report = []
for study,group in sorted(groups.items()):
    decisions = {r["decision"] for r in group}
    titles = {(r["title"],r["year"]) for r in group}
    conflict_fields = [field for field in ["decision", "title", "year"]
                       if len({r[field] for r in group}) > 1]
    conflict = bool(conflict_fields)
    differences = "; ".join(field + ": " + ", ".join(
        r["record_id"] + "=" + r[field] for r in group)
        for field in conflict_fields)
    decision = "review conflict" if conflict else group[0]["decision"]
    report.append(dict(study_id=study,
        record_ids="; ".join(r["record_id"] for r in group),
        retrieved_records=len(group),decision=decision,
        conflict_fields="; ".join(conflict_fields),
        supplied_differences=differences,
        source_locator="; ".join("citations.csv:" + r["record_id"] for r in group),
        reason="; ".join(sorted({r["reason"] for r in group if r["reason"]})) + ("; " if differences and any(r["reason"] for r in group) else "") + differences))
save_rows("study_screening.csv",["study_id", "record_ids", "retrieved_records", "decision", "conflict_fields", "supplied_differences", "source_locator", "reason"],report)
counts = Counter(r["decision"] for r in report)
print("Retrieved records:",len(rows))
print("Study groups:",len(report))
print("Additional records within groups:",len(rows)-len(report))
for decision in ["include","exclude","pending","review conflict"]:
    print(decision+":",counts[decision])
