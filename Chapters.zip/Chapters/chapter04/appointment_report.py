import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent

SCHEMAS = {'appointments.csv': ['appointment_id', 'scheduled_date', 'status', 'completed_date']}

def read_rows(name):
    with (ROOT / name).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream, strict=True)
        if reader.fieldnames != SCHEMAS[name]:
            raise ValueError("Wrong header in " + name)
        rows = list(reader)
    if any(None in row or None in row.values() for row in rows):
        raise ValueError("Malformed CSV row in " + name)
    return rows

from datetime import date as _date

def parse_day(value):
    day = _date.fromisoformat(value)
    if day.isoformat() != value:
        raise ValueError("Use exact YYYY-MM-DD dates")
    return day


def save_rows(name, fields, rows):
    with (ROOT / name).open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

from collections import Counter
from datetime import date

rows = read_rows("appointments.csv")
ids = Counter(r["appointment_id"].strip() for r in rows)
output = []
allowed = {"completed", "cancelled", "no_show"}
for number, row in enumerate(rows, 1):
    key = row["appointment_id"].strip()
    status = row["status"].strip().lower()
    issues = []
    if not key or ids[key] > 1 or row["appointment_id"] != key:
        issues.append("blank, padded, or duplicate appointment_id")
    try:
        scheduled = parse_day(row["scheduled_date"])
    except ValueError:
        issues.append("invalid scheduled date")
    if status not in allowed:
        issues.append("unrecognized status")
    eligible = not issues
    completed = False
    if status == "completed":
        try:
            finished = parse_day(row["completed_date"])
            if eligible and finished < scheduled:
                issues.append("completion precedes appointment")
            elif eligible:
                completed = True
        except ValueError:
            issues.append("missing or invalid completion date")
    output.append(dict(row, data_row=number,
        eligible=int(eligible), completed=int(completed),
        unresolved=int(bool(issues)), reason="; ".join(issues)))
save_rows("appointment_report.csv", SCHEMAS["appointments.csv"] + ["data_row", "eligible", "completed", "unresolved", "reason"], output)
denominator = sum(r["eligible"] for r in output)
numerator = sum(r["completed"] for r in output)
print("Rows:", len(output))
print("Eligible:", denominator)
print("Completed with a valid date:", numerator)
print("Unresolved:", sum(r["unresolved"] for r in output))
print("Proportion:", f"{numerator}/{denominator} = {numerator/denominator:.1%}"
      if denominator else "not calculable")
