import csv
from collections import defaultdict
from datetime import date, timedelta
from html import escape
from pathlib import Path

FIELDS = ["event_id", "person_ref", "encounter_id",
          "event_date", "event_type", "detail"]
KINDS = ["visit", "test", "measurement", "followup"]
COLORS = ["#175078", "#6b4697", "#936019", "#267054"]

def read_events(path):
    with Path(path).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream, strict=True)
        if reader.fieldnames != FIELDS:
            raise ValueError("Expected header: " + ",".join(FIELDS))
        rows = list(reader)
    if any(None in row or None in row.values() for row in rows):
        raise ValueError("Malformed CSV row")
    return rows

def save_csv(path, rows, fields):
    with Path(path).open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

def clean_events(rows):
    # Chapter 1 starts with a well-formed file, not a repair task.
    ids = [r["event_id"] for r in rows]
    if len(set(ids)) != len(ids):
        raise ValueError("Duplicate event ID; use the Chapter 2 checker")
    for row in rows:
        for key in ["event_id", "person_ref", "encounter_id"]:
            if row[key] != row[key].strip():
                raise ValueError("Padded identifier: " + key)
        if any(not row[k].strip() for k in FIELDS):
            raise ValueError("Blank field; use the Chapter 2 checker")
        day = date.fromisoformat(row["event_date"])
        if day.isoformat() != row["event_date"]:
            raise ValueError("Use YYYY-MM-DD")
        if row["event_type"] not in KINDS:
            raise ValueError("Unrecognized event type")
    return [dict(r, data_row=i, owner_ref=r["person_ref"],
                 status="placed", issues="")
            for i, r in enumerate(rows, 1)]

def event_key(row):
    return (row["event_date"], KINDS.index(row["event_type"]),
            row["event_id"], row["data_row"])

def timeline_svg(rows, first, last):
    # One marker per date and type; coincident events share a marker.
    span = max((last-first).days, 1)
    x = lambda day: 125 + 715*(day-first).days/span
    groups = defaultdict(list)
    for row in rows:
        groups[(row["event_date"], row["event_type"])].append(row)
    parts = ['<svg xmlns="http://www.w3.org/2000/svg" '
             'viewBox="0 0 900 230" role="img" style="font:14px sans-serif" '
             'aria-label="Recorded events by date and type">']
    for offset in sorted({round(span*i/5) for i in range(6)}):
        day = first + timedelta(days=offset)
        xx = x(day)
        parts.append(f'<path d="M{xx} 25 V190" stroke="#dde3e8"/>'
                     f'<text x="{xx}" y="214" text-anchor="middle">'
                     f'{day:%d %b}</text>')
    for lane, kind in enumerate(KINDS):
        yy = 40 + 44*lane
        parts.append(f'<text x="5" y="{yy+5}">{kind}</text>')
        parts.append(f'<path d="M125 {yy} H840" stroke="#d4dce4"/>')
    for (day, kind), events in sorted(groups.items()):
        lane = KINDS.index(kind)
        xx, yy = x(date.fromisoformat(day)), 40+44*lane
        label = events[0]["event_id"] if len(events)==1 else f"{len(events)} events"
        tip = "; ".join(f'{r["event_id"]}: {r["detail"]} '
                        f'({r["encounter_id"]})' for r in events)
        parts.append(f'<a tabindex="0" href="#event-{events[0]["data_row"]}">'
                     f'<title>{escape(tip)}</title>'
                     f'<circle cx="{xx}" cy="{yy}" r="7" fill="{COLORS[lane]}"/>'
                     f'<text x="{xx}" y="{yy-12}" text-anchor="middle">'
                     f'{escape(label)}</text></a>')
    return "".join(parts) + "</svg>"

def render_page(report, title="Patient-journey timeline"):
    people = sorted({r["owner_ref"] for r in report})
    placed = [r for r in report if r["status"]=="placed"]
    dates = [date.fromisoformat(r["event_date"]) for r in placed]
    first, last = (min(dates), max(dates)) if dates else (date(2026,6,1), date(2026,6,2))
    page = ['<!doctype html><html lang="en"><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1">'
            '<title>'+escape(title)+'</title><style>'
            'body{font:17px system-ui;color:#243544;background:#f1f5f8;margin:0}'
            'main{max-width:1100px;margin:auto;padding:28px}'
            'h1{color:#175078}section{background:white;padding:22px;margin:22px 0;'
            'border:1px solid #d4dce4;border-radius:10px}'
            'svg{width:100%;min-width:650px;font:14px system-ui}'
            '.scroll{overflow-x:auto}table{border-collapse:collapse;width:100%}'
            'th,td{text-align:left;padding:9px;border-bottom:1px solid #dde3e8}'
            '.review{background:#fff1dc}tr:target{outline:2px solid #175078}'
            'select{font:inherit;padding:7px}.note{max-width:850px}'
            '@media print{body{background:white}select{display:none}}'
            '</style><main><h1>'+escape(title)+'</h1>'
            '<p class="note">SYNTHETIC TEACHING RECORDS. '
            'Events are recorded information, not diagnoses or recommendations. '
            'Select a person; hover over or select a marker for details. '
            'Same-day positions do not establish time-of-day order.</p>'
            '<label>Person <select id="person"><option value="">All people</option>']
    page.extend('<option>'+escape(p)+'</option>' for p in people)
    page.append('</select></label><p id="count" aria-live="polite"></p>')
    if not people:
        page.append("<p>No event records were supplied.</p>")
    for person in people:
        group = [r for r in report if r["owner_ref"]==person]
        good = sorted((r for r in group if r["status"]=="placed"),key=event_key)
        bad = [r for r in group if r["status"]!="placed"]
        page.append('<section data-person="'+escape(person,quote=True)+
                    f'" data-total="{len(group)}" data-placed="{len(good)}" '
                    f'data-review="{len(bad)}"><h2>'+escape(person)+'</h2>')
        page.append('<div class="scroll">'+timeline_svg(good,first,last)+'</div>'
                    if good else '<p>No dated events can be placed.</p>')
        page.append('<h3>Recorded events</h3><div class="scroll"><table>'
                    '<tr><th>ID</th><th>Date</th><th>Type</th>'
                    '<th>Encounter</th><th>Detail</th></tr>')
        for row in good:
            page.append(f'<tr id="event-{row["data_row"]}">'+
                "".join("<td>"+escape(row[k])+"</td>"
                        for k in ["event_id","event_date","event_type","encounter_id","detail"])+"</tr>")
        page.append("</table></div>")
        if bad:
            page.append('<h3>Not placed: review data</h3><div class="scroll"><table>'
                        '<tr><th>Row</th><th>ID</th><th>Supplied person</th>'
                        '<th>Supplied date</th><th>Issue</th></tr>')
            for row in bad:
                page.append('<tr class="review">'+
                    "".join("<td>"+escape(str(row[k]))+"</td>"
                            for k in ["data_row","event_id","person_ref","event_date","issues"])+"</tr>")
            page.append("</table></div>")
        page.append("</section>")
    page.append("""<script>
const picker=document.getElementById("person");
function selectPerson(){
 let total=0,placed=0,review=0;
 document.querySelectorAll("section[data-person]").forEach(s=>{
  s.hidden=picker.value!=="" && s.dataset.person!==picker.value;
  if(!s.hidden){total+=Number(s.dataset.total);
   placed+=Number(s.dataset.placed);review+=Number(s.dataset.review);}
 });
 document.getElementById("count").textContent=
 total+" records | "+placed+" placed | "+review+" for review";
}
picker.addEventListener("change",selectPerson);selectPerson();
</script></main></html>""")
    return "".join(page)

def main():
    root = Path(__file__).resolve().parent
    report = clean_events(read_events(root/"journey_demo.csv"))
    fields = FIELDS + ["data_row","owner_ref","status","issues"]
    save_csv(root/"journey_events.csv",sorted(report,key=lambda r:
             (r["owner_ref"],)+event_key(r)),fields)
    with (root/"journey_timeline.html").open("x",encoding="utf-8") as stream:
        stream.write(render_page(report))
    print("People:",len({r["person_ref"] for r in report}))
    print("Encounters:",len({r["encounter_id"] for r in report}))
    print("Events:",len(report))
    print("Saved journey_timeline.html and journey_events.csv")

if __name__ == "__main__":
    main()
