import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent

SCHEMAS = {'cohort_candidates.csv': ['person_ref', 'age_years', 'enrolled', 'followup_recorded', 'wait_days']}

def read_rows(name):
    with (ROOT / name).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream, strict=True)
        if reader.fieldnames != SCHEMAS[name]:
            raise ValueError("Wrong header in " + name)
        rows = list(reader)
    if any(None in row or None in row.values() for row in rows):
        raise ValueError("Malformed CSV row in " + name)
    return rows

from datetime import date as _date


def require_ids(rows, field):
    keys = [r[field] for r in rows]
    if any(not k.strip() or k != k.strip() for k in keys):
        raise ValueError("IDs must be nonblank and unpadded: " + field)
    if len(set(keys)) != len(keys):
        raise ValueError("Duplicate ID: " + field)

def save_rows(name, fields, rows):
    with (ROOT / name).open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

import statistics
from collections import Counter

rows = read_rows("cohort_candidates.csv")
require_ids(rows, "person_ref")
import math
for row in rows:
    if row["age_years"].strip():
        age = int(row["age_years"])
        if age < 0:
            raise ValueError("Age must be a nonnegative integer")
    if row["wait_days"].strip():
        wait = float(row["wait_days"])
        if not math.isfinite(wait) or wait < 0:
            raise ValueError("Waiting time must be finite and nonnegative")
flow = []
eligible = []
for row in rows:
    if row["enrolled"] not in {"yes","no"} or row["followup_recorded"] not in {"yes","no"}:
        raise ValueError("Unexpected yes/no value")
    if not row["age_years"].strip():
        reason = "age unresolved"
    elif int(row["age_years"]) < 18:
        reason = "under 18"
    elif row["enrolled"] != "yes":
        reason = "not enrolled"
    else:
        reason = "included"
        eligible.append(row)
    flow.append(dict(person_ref=row["person_ref"], disposition=reason))
waits = [float(r["wait_days"]) for r in eligible if r["wait_days"].strip()]
followed = sum(r["followup_recorded"] == "yes" for r in eligible)
summary = [
    dict(measure="candidates", value=len(rows), basis_n=len(rows)),
    dict(measure="eligible", value=len(eligible), basis_n=len(rows)),
    dict(measure="followup_recorded", value=followed, basis_n=len(eligible)),
    dict(measure="observed_waits", value=len(waits), basis_n=len(eligible)),
    dict(measure="median_wait_days", value=statistics.median(waits) if waits else "",
         basis_n=len(waits))]
counts = Counter(r["disposition"] for r in flow)
flow_summary = [dict(disposition=reason, count=counts[reason])
    for reason in ["age unresolved", "under 18", "not enrolled", "included"]]
save_rows("cohort_ledger.csv", ["person_ref", "disposition"], flow)
save_rows("cohort_flow.csv", ["disposition","count"], flow_summary)
save_rows("cohort_summary.csv", ["measure","value","basis_n"], summary)
for row in summary:
    print(f'{row["measure"]}: {row["value"]} (basis n={row["basis_n"]})')
