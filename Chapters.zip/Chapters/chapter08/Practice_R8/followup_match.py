import argparse
import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DEFAULT_WINDOW_DAYS = 14

SCHEMAS = {'followups.csv': ['followup_id', 'encounter_id', 'followup_date'], 'encounters.csv': ['encounter_id', 'person_ref', 'index_date']}

def read_rows(name):
    with (ROOT / name).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream, strict=True)
        if reader.fieldnames != SCHEMAS[name]:
            raise ValueError("Wrong header in " + name)
        rows = list(reader)
    if any(None in row or None in row.values() for row in rows):
        raise ValueError("Malformed CSV row in " + name)
    return rows

from datetime import date as _date

def parse_day(value):
    day = _date.fromisoformat(value)
    if day.isoformat() != value:
        raise ValueError("Use exact YYYY-MM-DD dates")
    return day

def require_ids(rows, field):
    keys = [r[field] for r in rows]
    if any(not k.strip() or k != k.strip() for k in keys):
        raise ValueError("IDs must be nonblank and unpadded: " + field)
    if len(set(keys)) != len(keys):
        raise ValueError("Duplicate ID: " + field)

def save_rows(name, fields, rows):
    with (ROOT / name).open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

from datetime import date

parser = argparse.ArgumentParser(description="Match synthetic encounter follow-ups")
parser.add_argument("--window-days", type=int, default=DEFAULT_WINDOW_DAYS)
args = parser.parse_args()
if args.window_days < 0:
    parser.error("Window must be nonnegative")
encounters = read_rows("encounters.csv")
followups = read_rows("followups.csv")
require_ids(encounters, "encounter_id")
require_ids(followups, "followup_id")
for row in encounters:
    if not row["person_ref"].strip() or row["person_ref"] != row["person_ref"].strip():
        raise ValueError("Nonblank unpadded person reference required")
for row in followups:
    if not row["encounter_id"].strip() or row["encounter_id"] != row["encounter_id"].strip():
        raise ValueError("Nonblank unpadded encounter reference required")
    parse_day(row["followup_date"])
known = {r["encounter_id"] for r in encounters}
matches = []
candidates = []
for encounter in encounters:
    start = parse_day(encounter["index_date"])
    valid = []
    for event in followups:
        if event["encounter_id"] != encounter["encounter_id"]:
            continue
        days = (parse_day(event["followup_date"]) - start).days
        eligible = 0 <= days <= args.window_days
        candidates.append(dict(encounter_id=encounter["encounter_id"],
            followup_id=event["followup_id"], elapsed_days=days,
            within_window=int(eligible)))
        if eligible:
            valid.append((days, event["followup_id"]))
    valid.sort()
    matches.append(dict(encounter_id=encounter["encounter_id"],
        candidates_in_window=len(valid),
        selected=valid[0][1] if valid else "",
        elapsed_days=valid[0][0] if valid else "",
        status="matched" if valid else "no match in window"))
save_rows("followup_matches.csv", ["encounter_id", "candidates_in_window", "selected", "elapsed_days", "status"], matches)
chosen = {r["selected"] for r in matches if r["selected"]}
for row in candidates:
    row["selected"] = int(row["followup_id"] in chosen)
    row["reason"] = ("selected" if row["selected"] else
                     "eligible; not selected by day/ID rule" if row["within_window"] else
                     "before index date" if row["elapsed_days"] < 0 else
                     "after window")
save_rows("followup_candidates.csv",
          ["encounter_id","followup_id","elapsed_days","within_window","selected","reason"], candidates)
orphans = [r for r in followups if r["encounter_id"] not in known]
save_rows("unmatched_followups.csv",
          ["followup_id","encounter_id","followup_date"], orphans)
print("Encounters:", len(matches))
print("Matched:", sum(r["status"] == "matched" for r in matches))
print("No match in window:", sum(r["status"] != "matched" for r in matches))
print("Unknown encounter references:", len(orphans))
