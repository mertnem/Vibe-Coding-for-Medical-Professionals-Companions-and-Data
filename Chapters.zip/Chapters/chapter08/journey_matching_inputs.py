"""Prepare Chapter 8 inputs from a checked synthetic journey file.

This conversion does not apply a matching window. It preserves all source
rows in a ledger and leaves the original file unchanged.
"""
import argparse
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path

import journey_check
import journey_view
from journey_check import check_events
from journey_view import FIELDS, read_events


def save_rows(path: Path, fields: list[str], rows: list[dict]) -> None:
    with path.open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def prepare(source: Path, destination: Path) -> dict[str, int]:
    source, destination = Path(source), Path(destination)
    rows = read_events(source)
    checked = check_events(rows)
    review = [row for row in checked if row["status"] != "placed"]
    if review:
        raise ValueError("Resolve journey review rows before this conversion")

    encounters, followups, ledger = [], [], []
    for number, row in enumerate(rows, 1):
        target, identifier, use = "", "", "not used for matching"
        if row["event_type"] == "visit":
            target, identifier, use = "encounters.csv", row["encounter_id"], "encounter"
            encounters.append(dict(encounter_id=row["encounter_id"],
                person_ref=row["person_ref"], index_date=row["event_date"]))
        elif row["event_type"] == "followup":
            target, identifier, use = "followups.csv", row["event_id"], "follow-up"
            followups.append(dict(followup_id=row["event_id"],
                encounter_id=row["encounter_id"], followup_date=row["event_date"]))
        ledger.append(dict(row, data_row=number, used_as=use,
                           output_file=target, output_id=identifier))

    encounters.sort(key=lambda row: row["encounter_id"])
    followups.sort(key=lambda row: row["followup_id"])
    counts = dict(input_events=len(rows), encounters=len(encounters),
                  followups=len(followups),
                  not_used=len(rows)-len(encounters)-len(followups))
    assert sum(Counter(row["used_as"] for row in ledger).values()) == len(rows)
    # Validate first; never reuse an existing output directory.
    destination.mkdir(parents=False, exist_ok=False)
    save_rows(destination / "encounters.csv",
              ["encounter_id", "person_ref", "index_date"], encounters)
    save_rows(destination / "followups.csv",
              ["followup_id", "encounter_id", "followup_date"], followups)
    save_rows(destination / "journey_conversion_ledger.csv",
              FIELDS+["data_row", "used_as", "output_file", "output_id"], ledger)
    modules = [Path(__file__), Path(journey_view.__file__),
               Path(journey_check.__file__)]
    record = dict(input_file=source.name,
        input_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        program_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                        for p in modules},
        rule="Visits become encounters; followup events become candidates; "
             "tests and measurements remain in the source ledger", **counts)
    with (destination / "conversion_record.json").open("x", encoding="utf-8") as stream:
        json.dump(record, stream, indent=2)
    return counts


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_csv")
    parser.add_argument("new_output_folder")
    args = parser.parse_args()
    try:
        counts = prepare(Path(args.input_csv), Path(args.new_output_folder))
    except (ValueError, OSError) as error:
        parser.exit(1, str(error)+"\n")
    for key, value in counts.items():
        print(key+":", value)


if __name__ == "__main__":
    main()
