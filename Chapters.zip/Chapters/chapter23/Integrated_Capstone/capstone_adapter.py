"""Integrate the book's synthetic matcher, weekly monitor, and worklist.

Stage A: 14 calendar days; all encounters in the dated week's denominator.
Stage B options are supplied teaching decisions, not clinical recommendations.
The original records always remain in the source ledger.
"""
import argparse
from collections import Counter, defaultdict
import csv
from datetime import date, timedelta
import hashlib
import json
from pathlib import Path
import platform
import shutil
import subprocess
import sys

from followup_worklist import classify, save_report, parse_day, FIELDS

ROOT = Path(__file__).resolve().parent
RELEASE = "medical-teaching-2026-09-19-r3"
SCHEMAS = {
    "capstone_encounters.csv": ["encounter_id", "person_ref", "index_date",
                                "contact_route", "owner"],
    "capstone_followups.csv": ["followup_id", "encounter_id", "followup_date"],
    "capstone_weeks.csv": ["week_start", "provisional"],
}
LEDGER_FIELDS = ["source_file", "data_row", "supplied_id", "encounter_id",
                 "person_ref", "index_date", "followup_date", "contact_route",
                 "owner", "disposition", "reason"]


def read_csv(path, fields=None):
    with Path(path).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream, strict=True)
        if fields is not None and reader.fieldnames != fields:
            raise ValueError("Wrong header in " + Path(path).name)
        rows = list(reader)
    if any(None in r or None in r.values() for r in rows):
        raise ValueError("Malformed CSV record in " + Path(path).name)
    return rows


def save_csv(path, fields, rows):
    with Path(path).open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def checksum(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require_id(value):
    return bool(value.strip()) and value == value.strip()


def monday(day):
    return day - timedelta(days=day.weekday())


def run_chapter(name, folder, *args):
    """Execute an unchanged copy of the released chapter script."""
    shutil.copy2(ROOT / name, folder / name)
    result = subprocess.run([sys.executable, str(folder / name), *args],
                            cwd=folder, text=True, capture_output=True)
    (folder / "execution.txt").write_text(
        result.stdout + result.stderr, encoding="utf-8")
    if result.returncode:
        raise RuntimeError(name + " failed: " + result.stderr)


def build(destination, as_of, window=14, denominator="all"):
    if window < 0 or denominator not in {"all", "closed"}:
        raise ValueError("Invalid window or denominator decision")
    source = {name: read_csv(ROOT / name, fields)
              for name, fields in SCHEMAS.items()}
    encounters = source["capstone_encounters.csv"]
    followups = source["capstone_followups.csv"]
    flags = source["capstone_weeks.csv"]
    ids = [r["encounter_id"] for r in encounters]
    if len(set(ids)) != len(ids) or not all(require_id(x) for x in ids):
        raise ValueError("Distinct nonblank unpadded encounter IDs required")
    if not encounters:
        raise ValueError("The integration requires at least one encounter")
    starts = {}
    for r in encounters:
        if not require_id(r["person_ref"]):
            raise ValueError("Nonblank unpadded person reference required")
        starts[r["encounter_id"]] = parse_day(r["index_date"])
    flag_map = {}
    for r in flags:
        day = parse_day(r["week_start"])
        if day.weekday() != 0 or day in flag_map or r["provisional"] not in {"yes", "no"}:
            raise ValueError("Distinct Monday weeks with explicit yes/no flags required")
        flag_map[day] = r["provisional"]
    needed = {monday(x) for x in starts.values()}
    if set(flag_map) != needed:
        raise ValueError("Supply exactly one status flag for every encounter week")
    known = set(ids)
    duplicated = Counter(r["followup_id"].strip() for r in followups)
    upstream = defaultdict(list)
    matcher_followups = []
    recorded_dates = defaultdict(list)
    ledger = []
    for number, row in enumerate(followups, 1):
        identity, encounter = row["followup_id"], row["encounter_id"]
        issues = []
        if not require_id(identity):
            issues.append("blank or padded follow-up ID")
        if identity.strip() and duplicated[identity.strip()] > 1:
            issues.append("duplicate follow-up ID")
        if not require_id(encounter):
            issues.append("blank or padded encounter reference")
        if encounter not in known:
            issues.append("unknown encounter reference")
        day = None
        try:
            day = parse_day(row["followup_date"])
        except ValueError:
            issues.append("invalid follow-up date")
        if day and day > as_of:
            issues.append("future follow-up")
        usable = not issues
        if usable:
            # A negative-day candidate is visible to the matcher, but is also
            # an upstream issue for the worklist. It is never a recorded date.
            matcher_followups.append(dict(row))
            elapsed = (day - starts[encounter]).days
            if elapsed >= 0:
                recorded_dates[encounter].append((day, identity))
            else:
                issues.append("follow-up before index date")
        if encounter in known and issues:
            upstream[encounter].extend(issues)
        disposition = ("matcher candidate; review" if usable and issues else
                       "matcher candidate" if usable else "withheld; review")
        ledger.append(dict(source_file="capstone_followups.csv", data_row=number,
            supplied_id=identity, encounter_id=encounter, person_ref="", index_date="",
            followup_date=row["followup_date"], contact_route="", owner="",
            disposition=disposition, reason="; ".join(issues)))
    work_input = []
    for row in encounters:
        dates = sorted(recorded_dates[row["encounter_id"]])
        work_input.append({key: (dates[0][0].isoformat() if dates else "")
                           if key == "followup_date" else row[key] for key in FIELDS})
    work_report = classify(work_input, as_of, window, upstream)
    work_by_id = {r["encounter_id"]: r for r in work_report}
    for number, row in enumerate(encounters, 1):
        reviewed = work_by_id[row["encounter_id"]]
        ledger.append(dict(source_file="capstone_encounters.csv", data_row=number,
            supplied_id=row["encounter_id"], **row, followup_date="",
            disposition="encounter retained", reason=reviewed["reason"]))
    ledger.sort(key=lambda r: (r["source_file"], r["data_row"]))
    target = Path(destination).resolve()
    target.mkdir(parents=False, exist_ok=False)
    matching, weekly, worklist = (target / s for s in ("matching", "weekly", "worklist"))
    for folder in (matching, weekly, worklist):
        folder.mkdir()
    save_csv(target / "source_ledger.csv", LEDGER_FIELDS, ledger)
    save_csv(matching / "encounters.csv", ["encounter_id", "person_ref", "index_date"],
             [{k: r[k] for k in ["encounter_id", "person_ref", "index_date"]} for r in encounters])
    save_csv(matching / "followups.csv", SCHEMAS["capstone_followups.csv"], matcher_followups)
    run_chapter("followup_match.py", matching, "--window-days", str(window))
    matches = read_csv(matching / "followup_matches.csv")
    matched = {r["encounter_id"] for r in matches if r["selected"]}
    save_csv(worklist / "worklist_encounters.csv", FIELDS, work_input)
    save_report(worklist, work_report, as_of, window, worklist / "worklist_encounters.csv")
    denominator_ledger = []
    for row in encounters:
        eid = row["encounter_id"]
        due = starts[eid] + timedelta(days=window)
        included = denominator == "all" or as_of > due
        denominator_ledger.append(dict(encounter_id=eid,
            week_start=monday(starts[eid]).isoformat(), due_date=due.isoformat(),
            included=int(included), reason=("all supplied encounters" if denominator == "all" else
                "window closed before reporting date" if included else
                "window remains open through its end date")))
    save_csv(target / "denominator_ledger.csv", ["encounter_id", "week_start", "due_date",
                                              "included", "reason"], denominator_ledger)
    included = {r["encounter_id"] for r in denominator_ledger if r["included"]}
    week_map, week_counts, monitor_input = [], [], []
    for number, day in enumerate(sorted(flag_map), 1):
        group = {eid for eid in ids if monday(starts[eid]) == day} & included
        positives = group & matched
        review = {eid for eid in group if work_by_id[eid]["status"] == "review data"}
        monitor_input.append(dict(week=number, completed=len(positives), eligible=len(group),
                                  unresolved=len(review), provisional=flag_map[day]))
        week_map.append(dict(week=number, week_start=day.isoformat(), provisional=flag_map[day],
                             as_of=as_of.isoformat(), window_days=window, denominator=denominator))
        week_counts.append(dict(week_start=day.isoformat(), confirmed=len(positives),
            eligible=len(group), review=len(review), provisional=flag_map[day],
            numerator_ids=";".join(sorted(positives)), review_ids=";".join(sorted(review))))
    save_csv(target / "week_map.csv", ["week", "week_start", "provisional", "as_of",
                                      "window_days", "denominator"], week_map)
    save_csv(target / "weekly_counts.csv", ["week_start", "confirmed", "eligible", "review",
                                          "provisional", "numerator_ids", "review_ids"], week_counts)
    save_csv(weekly / "weekly_followup.csv", ["week", "completed", "eligible", "unresolved",
                                            "provisional"], monitor_input)
    run_chapter("weekly_followup.py", weekly)
    record = dict(release=RELEASE, python=platform.python_version(), as_of=as_of.isoformat(),
        window_days=window, denominator=denominator,
        closed_definition="as_of is strictly later than index_date plus window_days",
        source_records=len(ledger), encounters=len(encounters), followups=len(followups),
        flag_records=len(flags), matched=len(matched),
        worklist_counts=dict(Counter(r["status"] for r in work_report)),
        inputs={name: checksum(ROOT / name) for name in SCHEMAS},
        programs={name: checksum(ROOT / name) for name in
                  ["capstone_adapter.py", "followup_match.py", "weekly_followup.py", "followup_worklist.py"]})
    (target / "integration_record.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    print("Source ledger:", len(ledger), "records;", len(flags), "separate weekly flags")
    print("Within-window matches:", len(matched))
    for status in ["follow-up recorded", "no follow-up after window", "window still open", "review data"]:
        print(status + ":", record["worklist_counts"].get(status, 0))
    print("Saved", target.name)
    return target


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="integrated_run")
    parser.add_argument("--as-of", default="2026-09-17")
    parser.add_argument("--window-days", type=int, default=14)
    parser.add_argument("--denominator", choices=["all", "closed"], default="all")
    args = parser.parse_args()
    try:
        build(ROOT / args.output, parse_day(args.as_of), args.window_days, args.denominator)
    except (ValueError, OSError, RuntimeError) as error:
        parser.exit(1, str(error) + "\n")


if __name__ == "__main__":
    main()
