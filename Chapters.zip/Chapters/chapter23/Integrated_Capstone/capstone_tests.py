"""Independent named-case checks for the printed stage-A capstone fixture.

These expected answers belong to the 14-day/all-encounters contract. A stage-B
change requires separately justified expectations, not relabelled PASS results.
"""
import argparse
from collections import Counter
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def read(path):
    with Path(path).open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="integrated_run")
    parser.add_argument("--report", default="capstone_tests.csv")
    args = parser.parse_args()
    target = ROOT / args.output
    record = json.loads((target / "integration_record.json").read_text())
    encounters = read(ROOT / "capstone_encounters.csv")
    followups = read(ROOT / "capstone_followups.csv")
    ledger = read(target / "source_ledger.csv")
    matches = read(target / "matching/followup_matches.csv")
    worklist = read(target / "worklist/followup_worklist.csv")
    weeks = read(target / "weekly_counts.csv")
    by_id = {r["encounter_id"]: r for r in worklist}
    matched = {r["encounter_id"] for r in matches if r["status"] == "matched"}
    expected_matched = {"C101", "C102", "C107", "C111", "C112", "C113", "C114", "C115",
                        "C116", "C117", "C118"}
    expected_recorded = (expected_matched - {"C114"}) | {"C103"}
    results = []

    def trial(name, operation):
        try:
            operation()
        except Exception as error:
            results.append(dict(test=name, status="FAIL", detail=str(error)))
        else:
            results.append(dict(test=name, status="PASS", detail=""))

    def contract():
        check(record["as_of"] == "2026-09-17" and record["window_days"] == 14 and
              record["denominator"] == "all", "These are stage-A expectations; review changed rules")

    def source_conservation():
        expected = Counter((name, str(i)) for name, rows in
                           [("capstone_encounters.csv", encounters), ("capstone_followups.csv", followups)]
                           for i in range(1, len(rows)+1))
        check(len(ledger) == 40, "The ledger must contain all forty source rows")
        check(Counter((r["source_file"], r["data_row"]) for r in ledger) == expected,
              "Source locators are missing or duplicated")
        indexed = {(r["source_file"], int(r["data_row"])): r for r in ledger}
        for name, rows in [("capstone_encounters.csv", encounters), ("capstone_followups.csv", followups)]:
            for number, row in enumerate(rows, 1):
                actual = indexed[(name, number)]
                for key, value in row.items():
                    output_key = "supplied_id" if key == "followup_id" else key
                    check(actual[output_key] == value, "Changed source value: " + str((name, number, key)))

    def encounter_conservation():
        expected = Counter(r["encounter_id"] for r in encounters)
        check(len(worklist) == 20 and Counter(r["encounter_id"] for r in worklist) == expected,
              "Worklist must retain every encounter exactly once")
        check(Counter(r["encounter_id"] for r in matches) == expected,
              "Matcher must retain every encounter exactly once")

    def matching_identities():
        check(matched == expected_matched, "Wrong within-window encounter identities")
        selected = {r["encounter_id"]: r["selected"] for r in matches}
        check(selected["C101"] == "F01" and selected["C107"] == "F07", "Earliest candidate rule changed")

    def status_identities():
        groups = {s: {r["encounter_id"] for r in worklist if r["status"] == s}
                  for s in ["follow-up recorded", "review data", "no follow-up after window", "window still open"]}
        check(groups["follow-up recorded"] == expected_recorded, "Wrong recorded encounter identities")
        check(groups["review data"] == {"C104", "C105", "C106", "C108", "C109", "C114", "C120"},
              "Wrong review encounter identities")
        check(groups["no follow-up after window"] == {"C110"}, "C110 alone has a passed window")
        check(groups["window still open"] == {"C119"}, "C119 alone has an open window")

    def late_record():
        check(by_id["C103"]["followup_date"] == "2026-09-17" and
              by_id["C103"]["status"] == "follow-up recorded" and "C103" not in matched,
              "C103 day-16 follow-up must remain recorded, but not matched")

    def review_overlap():
        check("C114" in matched and by_id["C114"]["status"] == "review data" and
              "contact route missing" in by_id["C114"]["reason"],
              "C114 has a confirmed match and an independently missing contact")

    def boundary():
        check(by_id["C119"]["due_date"] == "2026-09-17" and
              by_id["C119"]["status"] == "window still open", "The end date is inclusive")
        check(by_id["C102"]["followup_date"] == "2026-09-15" and "C102" in matched,
              "C102 day-14 match is inclusive")

    def duplicates_and_orphan():
        duplicates = [r for r in ledger if r["source_file"] == "capstone_followups.csv" and r["supplied_id"] == "F09"]
        check(len(duplicates) == 2 and {r["data_row"] for r in duplicates} == {"9", "10"},
              "Both F09 source occurrences must remain")
        check(all("duplicate" in r["reason"] and "withheld" in r["disposition"] for r in duplicates),
              "Ambiguous F09 records must not enter matching")
        orphan = [r for r in ledger if r["source_file"] == "capstone_followups.csv" and r["supplied_id"] == "F11"]
        check(len(orphan) == 1 and orphan[0]["encounter_id"] == "C999" and
              "unknown encounter" in orphan[0]["reason"], "Unknown reference must remain explicit")

    def date_issues():
        for eid, reason in [("C104", "before index"), ("C105", "future"), ("C106", "invalid")]:
            check(by_id[eid]["status"] == "review data" and reason in by_id[eid]["reason"],
                  "Missing named date issue: " + eid)

    def weekly_values():
        check([(r["week_start"], r["confirmed"], r["eligible"], r["review"], r["provisional"]) for r in weeks] ==
              [("2026-08-31", "8", "16", "6", "no"), ("2026-09-07", "3", "4", "1", "yes")],
              "Wrong dated week counts or supplied flags")
        check(set(weeks[0]["numerator_ids"].split(";")) ==
              {"C101", "C102", "C107", "C111", "C112", "C113", "C114", "C115"},
              "Wrong final-week numerator identities")
        summary = {r["measure"]: r["value"] for r in read(target / "weekly/weekly_summary.csv")}
        check(summary["final_completed"] == "8" and summary["final_eligible"] == "16" and
              float(summary["pooled_final_percent"]) == 50.0, "Final pooled result must be 8/16")

    def dated_outputs():
        check(all(r["as_of"] == "2026-09-17" and r["window_days"] == "14" for r in worklist),
              "Worklist lost reporting assumptions")
        denominator = read(target / "denominator_ledger.csv")
        check(len(denominator) == 20 and all(r["included"] == "1" for r in denominator),
              "Stage A retains every encounter in the denominator ledger")
        check(record["source_records"] == 40 and record["flag_records"] == 2,
              "The forty source records and two flag records must remain distinct")

    for name, operation in [("stage_A_contract", contract), ("source_conservation", source_conservation),
        ("encounter_conservation", encounter_conservation), ("match_identities", matching_identities),
        ("status_identities", status_identities), ("late_followup", late_record),
        ("review_overlap", review_overlap), ("inclusive_boundary", boundary),
        ("duplicate_and_unknown", duplicates_and_orphan), ("date_issues", date_issues),
        ("dated_weekly_values", weekly_values), ("dated_outputs", dated_outputs)]:
        trial(name, operation)
    with (ROOT / args.report).open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=["test", "status", "detail"])
        writer.writeheader()
        writer.writerows(results)
    print("Passed:", sum(r["status"] == "PASS" for r in results))
    print("Failed:", sum(r["status"] == "FAIL" for r in results))
    for r in results:
        if r["status"] == "FAIL":
            print(r["test"] + ": " + r["detail"])
    if any(r["status"] == "FAIL" for r in results):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
