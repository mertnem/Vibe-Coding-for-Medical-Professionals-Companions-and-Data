"""Synthetic administrative worklist; no messages are sent."""
import argparse
import csv
import hashlib
import json
from collections import Counter
from datetime import date, timedelta
from html import escape
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FIELDS = ["encounter_id", "index_date", "followup_date", "contact_route", "owner"]
EXTRA = ["data_row", "as_of", "window_days", "rule_version", "due_date", "status", "reason"]
VERSION = "worklist-2"
STATUSES = ["follow-up recorded", "no follow-up after window",
            "window still open", "review data"]

def parse_day(value):
    day = date.fromisoformat(value)
    if day.isoformat() != value:
        raise ValueError("Use exact YYYY-MM-DD dates")
    return day

def read_rows(path):
    with Path(path).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream, strict=True)
        if reader.fieldnames != FIELDS:
            raise ValueError("Wrong worklist header")
        rows = list(reader)
    if any(None in r or None in r.values() for r in rows):
        raise ValueError("Malformed CSV row")
    return rows

def classify(rows, as_of, window=14, upstream=None):
    if not isinstance(window, int) or window < 0:
        raise ValueError("Window must be a nonnegative integer")
    ids = [r["encounter_id"] for r in rows]
    if (len(set(ids)) != len(ids) or
            any(not x.strip() or x != x.strip() for x in ids)):
        raise ValueError("Distinct nonblank unpadded encounter IDs required")
    report = []
    for number, row in enumerate(rows, 1):
        issues = list((upstream or {}).get(row["encounter_id"], []))
        start = due = followup = None
        try:
            start = parse_day(row["index_date"])
            due = start + timedelta(days=window)
        except (ValueError, OverflowError):
            issues.append("invalid index date or window end")
        if not row["contact_route"].strip():
            issues.append("contact route missing")
        if not row["owner"].strip():
            issues.append("owner missing")
        if row["followup_date"].strip():
            try:
                followup = parse_day(row["followup_date"])
            except ValueError:
                issues.append("invalid follow-up date")
        if followup and ((start and followup < start) or followup > as_of):
            issues.append("inconsistent follow-up date")
        if start and start > as_of:
            issues.append("future index date")
        if issues:
            status = "review data"
        elif followup:
            status = "follow-up recorded"
        elif as_of > due:
            status = "no follow-up after window"
        else:
            status = "window still open"
        report.append(dict(row, data_row=number, as_of=as_of.isoformat(),
            window_days=window, rule_version=VERSION,
            due_date=due.isoformat() if due else "", status=status,
            reason="; ".join(dict.fromkeys(issues))))
    return sorted(report, key=lambda r: (r["status"], r["due_date"], r["encounter_id"]))

def render_page(report, as_of, window=14):
    counts = Counter(r["status"] for r in report)
    options = '<option value="">All statuses</option>' + "".join(
        '<option value="'+escape(s, quote=True)+'">'+escape(s)+
        f' ({counts[s]})</option>' for s in STATUSES)
    owners = '<option value="">All owners</option>' + "".join(
        '<option>'+escape(s)+'</option>' for s in sorted({r["owner"] for r in report}) if s)
    visible = ["encounter_id", "owner", "due_date", "status", "reason"]
    body = "".join('<tr data-status="'+escape(r["status"], quote=True)+
        '" data-owner="'+escape(r["owner"], quote=True)+'">'+
        "".join('<td>'+escape(str(r[k]))+'</td>' for k in visible)+'</tr>' for r in report)
    return f'''<!doctype html><html lang="en"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Synthetic follow-up worklist</title>
<style>body{{font:18px system-ui;margin:24px}}td,th{{padding:10px;text-align:left;
border-bottom:1px solid #aaa}}.scroll{{overflow:auto}}select{{font:inherit}}
label{{display:inline-block;margin:8px 16px 8px 0}}</style>
<h1>Synthetic follow-up worklist</h1>
<p>As of {as_of.isoformat()}; window {window} calendar days; rules {VERSION}.</p>
<p>Administrative teaching records only. No clinical priority is assigned.
No messages are sent and no appointment is changed.</p>
<label>Status <select id="filter">{options}</select></label>
<label>Owner <select id="owner">{owners}</select></label>
<p id="count" aria-live="polite"></p><p id="empty" hidden>No rows match.</p>
<div class="scroll"><table><thead><tr><th>Encounter</th><th>Owner</th>
<th>Window end</th><th>Status</th><th>Reason</th></tr></thead>
<tbody>{body}</tbody></table></div><script>
function update(){{
 const status=document.getElementById("filter").value;
 const owner=document.getElementById("owner").value;
 let n=0;
 document.querySelectorAll("tbody tr").forEach(r=>{{
   r.hidden=(status!==""&&r.dataset.status!==status)||
            (owner!==""&&r.dataset.owner!==owner);
   if(!r.hidden)n++;
 }});
 document.getElementById("count").textContent=n+" of {len(report)} records shown";
 document.getElementById("empty").hidden=n!==0;
}}
document.getElementById("filter").addEventListener("change",update);
document.getElementById("owner").addEventListener("change",update);update();
</script></html>'''

def save_report(folder, report, as_of, window=14, input_path=None):
    folder = Path(folder)
    names = ["followup_worklist.csv", "followup_worklist.html", "worklist_run.json"]
    if any((folder/n).exists() for n in names):
        raise FileExistsError("Use a fresh output folder")
    with (folder/names[0]).open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS+EXTRA)
        writer.writeheader()
        writer.writerows(report)
    (folder/names[1]).write_text(render_page(report, as_of, window), encoding="utf-8")
    record = dict(as_of=as_of.isoformat(), window_days=window, rules=VERSION,
                  records=len(report), counts=dict(Counter(r["status"] for r in report)),
                  program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    if input_path is not None:
        record["input_sha256"] = hashlib.sha256(Path(input_path).read_bytes()).hexdigest()
    (folder/names[2]).write_text(json.dumps(record, indent=2), encoding="utf-8")

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--as-of", default="2026-09-17")
    parser.add_argument("--window-days", type=int, default=14)
    args = parser.parse_args()
    as_of = parse_day(args.as_of)
    source = ROOT/"worklist_encounters.csv"
    report = classify(read_rows(source), as_of, args.window_days)
    save_report(ROOT, report, as_of, args.window_days, source)
    for status in STATUSES:
        print(status+":", sum(r["status"]==status for r in report))

if __name__ == "__main__":
    main()
