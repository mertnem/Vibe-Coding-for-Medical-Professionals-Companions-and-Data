import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent

SCHEMAS = {'measurements.csv': ['observation_id', 'person_ref', 'encounter_id', 'measure', 'value', 'unit', 'source']}

def read_rows(name):
    with (ROOT / name).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream, strict=True)
        if reader.fieldnames != SCHEMAS[name]:
            raise ValueError("Wrong header in " + name)
        rows = list(reader)
    if any(None in row or None in row.values() for row in rows):
        raise ValueError("Malformed CSV row in " + name)
    return rows

from datetime import date as _date


def require_ids(rows, field):
    keys = [r[field] for r in rows]
    if any(not k.strip() or k != k.strip() for k in keys):
        raise ValueError("IDs must be nonblank and unpadded: " + field)
    if len(set(keys)) != len(keys):
        raise ValueError("Duplicate ID: " + field)

def save_rows(name, fields, rows):
    with (ROOT / name).open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

from collections import defaultdict

rows = read_rows("measurements.csv")
require_ids(rows, "observation_id")
for row in rows:
    for key in ["person_ref", "encounter_id", "measure", "unit", "source"]:
        if not row[key].strip() or row[key] != row[key].strip():
            raise ValueError("Blank or padded label: " + key)
groups = defaultdict(list)
for row in rows:
    groups[(row["measure"], row["unit"])].append(row)
catalogue = []
for (measure, unit), group in sorted(groups.items()):
    catalogue.append(dict(measure=measure, unit=unit,
        observations=len(group),
        supplied=sum(bool(r["value"].strip()) for r in group),
        missing=sum(not r["value"].strip() for r in group),
        sources="; ".join(sorted({r["source"] for r in group}))))
save_rows("measurement_catalogue.csv", ["measure", "unit", "observations", "supplied", "missing", "sources"], catalogue)
lineage = [dict(observation_id=r["observation_id"],
    person_ref=r["person_ref"], encounter_id=r["encounter_id"],
    catalogue_group=r["measure"] + " | " + r["unit"],
    source=r["source"]) for r in rows]
save_rows("observation_lineage.csv", ["observation_id", "person_ref", "encounter_id", "catalogue_group", "source"], lineage)
print("Observations:", len(rows))
print("People:", len({r["person_ref"] for r in rows}))
print("Encounters:", len({r["encounter_id"] for r in rows}))
print("Measure-unit groups:", len(catalogue))
