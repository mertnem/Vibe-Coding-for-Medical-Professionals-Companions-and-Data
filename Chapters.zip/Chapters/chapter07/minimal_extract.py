import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent

SCHEMAS = {'synthetic_schedule.csv': ['event_id', 'person_name', 'email', 'event_date', 'status', 'free_text']}

def read_rows(name):
    with (ROOT / name).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream, strict=True)
        if reader.fieldnames != SCHEMAS[name]:
            raise ValueError("Wrong header in " + name)
        rows = list(reader)
    if any(None in row or None in row.values() for row in rows):
        raise ValueError("Malformed CSV row in " + name)
    return rows

from datetime import date as _date

def parse_day(value):
    day = _date.fromisoformat(value)
    if day.isoformat() != value:
        raise ValueError("Use exact YYYY-MM-DD dates")
    return day

def require_ids(rows, field):
    keys = [r[field] for r in rows]
    if any(not k.strip() or k != k.strip() for k in keys):
        raise ValueError("IDs must be nonblank and unpadded: " + field)
    if len(set(keys)) != len(keys):
        raise ValueError("Duplicate ID: " + field)

def save_rows(name, fields, rows):
    with (ROOT / name).open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

from collections import Counter
from datetime import date, timedelta

rows = read_rows("synthetic_schedule.csv")
require_ids(rows, "event_id")
allowed = {"completed", "cancelled", "no_show"}
counts = Counter()
included = 0
for row in rows:
    day = parse_day(row["event_date"])
    if row["status"] not in allowed:
        raise ValueError("Unexpected status")
    if day.year == 2026 and day.month == 9:
        monday = day - timedelta(days=day.weekday())
        counts[(monday.isoformat(), row["status"])] += 1
        included += 1
report = [dict(week_start=week, status=status, count=count)
          for (week, status), count in sorted(counts.items())]
save_rows("weekly_counts.csv", ["week_start", "status", "count"], report)
receipt = [dict(item="input_rows", value=len(rows)),
           dict(item="included_rows", value=included),
           dict(item="outside_period", value=len(rows)-included),
           dict(item="export_columns", value="week_start; status; count")]
save_rows("extract_receipt.csv", ["item", "value"], receipt)
print("Input rows:", len(rows))
print("September rows:", included)
print("Outside period:", len(rows)-included)
print("Exported columns: week_start, status, count")
